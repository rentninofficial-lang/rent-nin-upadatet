## Website control panel

A new admin section at `/admin/site` with four tabs, each editing content that today is hardcoded or missing.

### 1. Site Content
Edit homepage hero and promo banners without code.
- Hero: headline, subheadline, background image, primary CTA label/href.
- Homepage sections toggle: show/hide "Featured properties", "Popular areas", "Categories", "Corporate leasing".
- Up to 3 promo banners (title, body, image, link, active flag).

### 2. Categories & taxonomies
CRUD over the existing `categories` table.
- Add/edit/delete categories (name, slug, icon, description, position).
- Drag-to-reorder (updates `position`).
- Curated Dhaka areas list (add/remove entries used by search autocomplete and homepage "Areas" section).

### 3. SEO & metadata
- Global defaults: site name, default title suffix, default meta description, default og:image, Twitter handle.
- Per-page overrides table: pick a route (`/`, `/renters`, `/landlords`, `/corporate`, `/about`, `/contact`, `/properties`) and override title, description, og:image, robots (index / noindex).
- Wired into `src/routes/__root.tsx` and each route's `head()` via a shared helper.

### 4. Site settings
- Contact: email, phone, address.
- WhatsApp number (used by the WhatsApp FAB and lead-shortlist links).
- Social links: Facebook, Instagram, LinkedIn, YouTube, X.
- Footer: about text, copyright.

## Technical

**Data model (migration):**
- `site_settings(key text primary key, value jsonb, updated_at)` — singleton rows keyed by section (`hero`, `banners`, `contact`, `socials`, `footer`, `seo_defaults`, `homepage_sections`, `dhaka_areas`).
- `page_seo(path text primary key, title text, description text, og_image text, robots text, updated_at)`.
- RLS: `SELECT TO anon` (public read for SSR), `ALL TO authenticated USING has_role(auth.uid(),'admin')` for writes. `GRANT SELECT` to anon, full CRUD to authenticated, ALL to service_role.

**Server functions (`src/lib/site.functions.ts`):**
- `getAllSiteSettings()` / `getPageSeo(path)` — public reads via publishable client.
- `adminUpsertSiteSetting({key, value})` / `adminUpsertPageSeo({...})` / `adminDeletePageSeo({path})` — behind `requireSupabaseAuth` + admin role check.
- Categories reuse existing admin patterns (extend `admin.functions.ts` with `adminCreateCategory`, `adminUpdateCategory`, `adminDeleteCategory`, `adminReorderCategories`).

**Admin UI:**
- `src/routes/_authenticated/admin.site.tsx` — tabbed page (Content | Categories | SEO | Settings).
- New nav entry in existing admin layout.
- Form persistence via React Hook Form + Zod, saves per-section.

**Wiring existing pages:**
- `src/routes/index.tsx` hero + homepage sections read from `site_settings` (loader prefetch).
- `src/components/whatsapp-fab.tsx` + WhatsApp helpers read phone from settings (with current constant as fallback).
- `src/components/site-footer.tsx` reads contact/socials/footer copy.
- `__root.tsx` head defaults read `seo_defaults`; per-route `head()` merges `page_seo` overrides.
- Seed migration writes current hardcoded values so nothing changes visually until an admin edits.

**Out of scope (say-so needed to add later):**
- Rich media library / image uploads UI beyond existing Supabase `avatars`/`property-photos` buckets — image fields accept URLs for now.
- Multilingual content.
- Draft/publish workflow for settings (edits go live immediately).
- Blog CMS.

Approve and I'll build it end-to-end.