# Proguard rules for the application
-keep class com.example.** { *; }
