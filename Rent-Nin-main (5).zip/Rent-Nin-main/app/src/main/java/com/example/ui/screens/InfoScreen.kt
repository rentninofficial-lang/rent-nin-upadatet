package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.BorderStroke
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.model.Property
import com.example.ui.RentViewModel
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InfoScreen(
    viewModel: RentViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var activeSubTab by remember { mutableStateOf(0) } // 0 = Support, 1 = Owner Dashboard

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primary)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(
                "Rentnin Portal",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }

        // Sub Tab Selector (Support, Landlord, Admin Panel, Area Guides)
        ScrollableTabRow(
            selectedTabIndex = activeSubTab,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Color.White,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        ) {
            Tab(
                selected = activeSubTab == 0,
                onClick = { activeSubTab = 0 },
                text = { Text("Support", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp) }
            )
            Tab(
                selected = activeSubTab == 1,
                onClick = { activeSubTab = 1 },
                text = { Text("Landlord Dashboard", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp) }
            )
            Tab(
                selected = activeSubTab == 2,
                onClick = { activeSubTab = 2 },
                text = { Text("Admin Panel", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp) }
            )
            Tab(
                selected = activeSubTab == 3,
                onClick = { activeSubTab = 3 },
                text = { Text("Area Guides", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp) }
            )
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeSubTab) {
                0 -> SupportTabView(viewModel = viewModel)
                1 -> LandlordDashboardView(viewModel = viewModel)
                2 -> AdminDashboardView(viewModel = viewModel)
                3 -> AreaGuidesView()
            }
        }
    }
}

@Composable
fun SupportTabView(viewModel: RentViewModel) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    var landlordName by remember { mutableStateOf("") }
    var landlordPhone by remember { mutableStateOf("") }
    var propertyAddress by remember { mutableStateOf("") }
    var propertyRent by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            "Customer Care",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                ContactRow(
                    icon = Icons.Filled.Call,
                    title = "Call Customer Care",
                    subtitle = "+880 1700-000000",
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+8801700000000"))
                        context.startActivity(intent)
                    }
                )
                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.LightGray.copy(alpha = 0.5f))
                ContactRow(
                    icon = Icons.Filled.Email,
                    title = "Email Assistance",
                    subtitle = "support@rentnin.com",
                    onClick = {
                        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:support@rentnin.com"))
                        context.startActivity(intent)
                    }
                )
                Divider(modifier = Modifier.padding(vertical = 12.dp), color = Color.LightGray.copy(alpha = 0.5f))
                ContactRow(
                    icon = Icons.Filled.Info,
                    title = "BST Operations Hours",
                    subtitle = "Sunday – Thursday · 9:00 AM – 8:00 PM",
                    onClick = {}
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            "Quick Listing Consultation",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            "Submit basic property specifications below, and our official vetting team will contact you to perform manual verification and upload photos.",
            color = Color.Gray,
            fontSize = 12.sp,
            lineHeight = 16.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = landlordName,
                    onValueChange = { landlordName = it },
                    label = { Text("Full Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = landlordPhone,
                    onValueChange = { landlordPhone = it },
                    label = { Text("Verification Contact Phone") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = propertyAddress,
                    onValueChange = { propertyAddress = it },
                    label = { Text("Exact Neighborhood Address") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = propertyRent,
                    onValueChange = { propertyRent = it },
                    label = { Text("Target Monthly Rent (BDT)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (landlordName.isEmpty() || landlordPhone.isEmpty() || propertyAddress.isEmpty()) {
                            Toast.makeText(context, "Please complete all mandatory fields.", Toast.LENGTH_SHORT).show()
                        } else {
                            val details = "Owner: $landlordName\nAddress: $propertyAddress\nMonthly Target: ৳$propertyRent"
                            viewModel.submitInquiry(
                                name = landlordName,
                                phone = landlordPhone,
                                details = details,
                                propertyTitle = "Vetting Request: $propertyAddress",
                                type = "Vetting Consult"
                            )
                            Toast.makeText(context, "Consultation requested! Our agent will call you shortly.", Toast.LENGTH_LONG).show()
                            landlordName = ""
                            landlordPhone = ""
                            propertyAddress = ""
                            propertyRent = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Text("Request Official Vetting", fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun LandlordDashboardView(viewModel: RentViewModel) {
    val context = LocalContext.current
    val properties by viewModel.allProperties.collectAsState(initial = emptyList())

    var selectedDashboardTab by remember { mutableStateOf(0) }
    val dashboardTabs = listOf("Active", "Pending Review", "Expired", "Sold/Rented", "Drafts")

    var showAddDialog by remember { mutableStateOf(false) }
    var draftIdBeingEdited by remember { mutableStateOf<String?>(null) }
    var showEditPriceDialog by remember { mutableStateOf<Property?>(null) }
    var newPriceText by remember { mutableStateOf("") }

    // Multi-Step Wizard States
    var wizardStep by remember { mutableStateOf(1) } // 1 to 8
    
    // Step 1: Category & Listing Type
    var wizardCategory by remember { mutableStateOf("Apartment") }
    var wizardListingType by remember { mutableStateOf("For Rent") }
    var wizardSubCategory by remember { mutableStateOf("Family") }

    // Step 2: Location
    var wizardNeighborhood by remember { mutableStateOf("Gulshan") }
    var wizardAddress by remember { mutableStateOf("") }
    var wizardLatitude by remember { mutableStateOf(23.7937) }
    var wizardLongitude by remember { mutableStateOf(90.4066) }
    var isMapPinDropped by remember { mutableStateOf(false) }

    // Step 3: Details
    var wizardTitle by remember { mutableStateOf("") }
    var wizardPrice by remember { mutableStateOf("") }
    var wizardSizeSqft by remember { mutableStateOf("") }
    var wizardBedrooms by remember { mutableStateOf("2") }
    var wizardBathrooms by remember { mutableStateOf("2") }
    var wizardFloorNumber by remember { mutableStateOf("1") }
    var wizardDescription by remember { mutableStateOf("") }
    var wizardFurnished by remember { mutableStateOf(false) }

    // Step 4: Photos (Minimum 3 selection)
    val photoOptions = listOf(
        "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&auto=format&fit=crop&q=60" to "Elegant Living Lounge",
        "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?w=600&auto=format&fit=crop&q=60" to "Gourmet Kitchen Set",
        "https://images.unsplash.com/photo-1613977257363-707ba9348227?w=600&auto=format&fit=crop&q=60" to "Luxurious Bedroom Suite",
        "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&auto=format&fit=crop&q=60" to "Chic Private Balcony",
        "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=600&auto=format&fit=crop&q=60" to "Modern Concept Bathroom",
        "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=60" to "Architectural Facade"
    )
    var selectedPhotos by remember { mutableStateOf(setOf<String>()) }

    // Step 5: Contact Info & Account Type
    var wizardSellerType by remember { mutableStateOf("Individual") } // "Individual", "Agent"
    var wizardSellerName by remember { mutableStateOf("") }
    var wizardSellerPhone by remember { mutableStateOf("") }

    // Step 6: OTP Verification
    var generatedOtp by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var otpVerified by remember { mutableStateOf(false) }
    var otpMessageTriggered by remember { mutableStateOf(false) }

    // Step 7: Monetization & Promotion Package
    var selectedPromoType by remember { mutableStateOf("Free") } // "Free", "Featured", "Urgent"
    var showBkashCheckout by remember { mutableStateOf(false) }
    var bkashWalletNumber by remember { mutableStateOf("") }
    var bkashOtpInput by remember { mutableStateOf("") }
    var bkashPinInput by remember { mutableStateOf("") }
    var bkashCheckoutStep by remember { mutableStateOf(1) } // 1 = Wallet, 2 = SMS OTP, 3 = PIN, 4 = Paid
    var promoPaid by remember { mutableStateOf(false) }

    // AI Integration States
    val scope = rememberCoroutineScope()
    var showAiPriceDialog by remember { mutableStateOf(false) }
    var aiPriceLoading by remember { mutableStateOf(false) }
    var aiPriceRecommendation by remember { mutableStateOf("") }
    var suggestedRentAmount by remember { mutableStateOf("") }
    var aiDescriptionKeywords by remember { mutableStateOf("") }
    var aiDescriptionLoading by remember { mutableStateOf(false) }
    var photoAltTexts by remember { mutableStateOf(mapOf<String, String>()) }

    // Helper functions to open/close wizard and reset fields
    val resetWizardFields = {
        wizardStep = 1
        wizardCategory = "Apartment"
        wizardListingType = "For Rent"
        wizardSubCategory = "Family"
        wizardNeighborhood = "Gulshan"
        wizardAddress = ""
        wizardLatitude = 23.7937
        wizardLongitude = 90.4066
        isMapPinDropped = false
        wizardTitle = ""
        wizardPrice = ""
        wizardSizeSqft = ""
        showAiPriceDialog = false
        aiPriceLoading = false
        aiPriceRecommendation = ""
        suggestedRentAmount = ""
        aiDescriptionKeywords = ""
        aiDescriptionLoading = false
        photoAltTexts = emptyMap()
        wizardBedrooms = "2"
        wizardBathrooms = "2"
        wizardFloorNumber = "1"
        wizardDescription = ""
        wizardFurnished = false
        selectedPhotos = emptySet()
        wizardSellerType = "Individual"
        wizardSellerName = ""
        wizardSellerPhone = ""
        generatedOtp = ""
        otpInput = ""
        otpVerified = false
        otpMessageTriggered = false
        selectedPromoType = "Free"
        showBkashCheckout = false
        bkashWalletNumber = ""
        bkashOtpInput = ""
        bkashPinInput = ""
        bkashCheckoutStep = 1
        promoPaid = false
        draftIdBeingEdited = null
    }

    val loadDraftToWizard = { draft: Property ->
        resetWizardFields()
        draftIdBeingEdited = draft.id
        wizardTitle = draft.title
        wizardCategory = draft.propertyType
        wizardListingType = "For Rent"
        wizardSubCategory = if (draft.subCategory.isBlank()) "Family" else draft.subCategory
        wizardPrice = draft.price.toInt().toString()
        wizardSizeSqft = draft.areaSqft.toString()
        wizardBedrooms = draft.bedrooms.toString()
        wizardBathrooms = draft.bathrooms.toString()
        wizardFloorNumber = "3" // Default fallback
        wizardNeighborhood = draft.neighborhood
        wizardAddress = draft.address
        wizardDescription = draft.description
        wizardFurnished = draft.furnished
        wizardSellerType = if (draft.sellerType.equals("agent", ignoreCase = true)) "Agent" else "Individual"
        wizardSellerName = draft.ownerName
        wizardSellerPhone = draft.ownerPhone
        
        // Populate pre-selected photos if any
        val list = mutableSetOf<String>()
        if (draft.imageUrl.isNotEmpty()) list.add(draft.imageUrl)
        if (draft.additionalImages.isNotBlank()) {
            list.addAll(draft.additionalImages.split(",").map { it.trim() }.filter { it.isNotEmpty() })
        }
        selectedPhotos = list
        
        wizardStep = 1
        showAddDialog = true
    }

    val saveCurrentAsDraft = {
        val draftId = draftIdBeingEdited ?: ("draft_" + UUID.randomUUID().toString().take(6))
        val draftProperty = Property(
            id = draftId,
            title = wizardTitle.ifBlank { "Untitled Draft Category: $wizardCategory" },
            slug = "draft-" + UUID.randomUUID().toString().take(6),
            description = wizardDescription.ifBlank { "Property draft details for listing." },
            listingType = "rent",
            price = wizardPrice.toDoubleOrNull() ?: 0.0,
            bedrooms = wizardBedrooms.toIntOrNull() ?: 0,
            bathrooms = wizardBathrooms.toIntOrNull() ?: 0,
            areaSqft = wizardSizeSqft.toIntOrNull() ?: 0,
            address = wizardAddress.ifBlank { "No Address" },
            city = "Dhaka",
            featured = selectedPromoType == "Featured",
            verified = false,
            audience = wizardSubCategory.lowercase(),
            imageUrl = selectedPhotos.firstOrNull() ?: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&auto=format&fit=crop&q=60",
            additionalImages = selectedPhotos.drop(1).joinToString(","),
            furnished = wizardFurnished,
            propertyType = wizardCategory,
            neighborhood = wizardNeighborhood,
            ownerName = wizardSellerName.ifBlank { "Unspecified Owner" },
            ownerPhone = wizardSellerPhone.ifBlank { "Unspecified Phone" },
            viewsCount = 0,
            isDraft = true,
            isApproved = false,
            promoType = if (selectedPromoType != "Free") selectedPromoType else "",
            sellerType = wizardSellerType.lowercase(),
            subCategory = wizardSubCategory
        )
        viewModel.addNewProperty(draftProperty)
        Toast.makeText(context, "💾 Draft listing saved successfully!", Toast.LENGTH_SHORT).show()
        showAddDialog = false
        resetWizardFields()
    }

    // Filter properties based on the selected Tab Row
    val filteredDashboardList = remember(properties, selectedDashboardTab) {
        properties.filter { p ->
            val daysLeft = 30 - ((System.currentTimeMillis() - p.timestamp) / (1000 * 60 * 60 * 24))
            val isExpired = daysLeft <= 0
            
            when (selectedDashboardTab) {
                0 -> !p.isDraft && p.isApproved && !p.isRented && !isExpired // Active
                1 -> !p.isDraft && !p.isApproved // Pending Review
                2 -> !p.isDraft && isExpired && !p.isRented // Expired
                3 -> !p.isDraft && p.isRented // Sold/Rented
                4 -> p.isDraft // Drafts
                else -> true
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Administration Header Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Rentnin Portal Administration",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Post verified listings via our multi-step creation wizard, manage saved drafts, renew expired posts, or simulate administrative reviews.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                resetWizardFields()
                                showAddDialog = true
                            },
                            modifier = Modifier.weight(1.1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Post an Ad", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                // Seeding with different states to demonstrate the feature-rich platform
                                val seedProps = listOf(
                                    Property(
                                        id = "seed_p_act_" + UUID.randomUUID().toString().take(4),
                                        title = "Featured 3BHK Penthouse in Gulshan",
                                        slug = "seed-p-act-1",
                                        description = "Magnificent modern top-floor penthouse with panoramic view of Gulshan lake. High-end marble floorings and fully furnished.",
                                        listingType = "rent",
                                        price = 150000.0,
                                        bedrooms = 3,
                                        bathrooms = 3,
                                        areaSqft = 2500,
                                        address = "Road 72, Gulshan 2",
                                        city = "Dhaka",
                                        featured = true,
                                        verified = true,
                                        audience = "family",
                                        imageUrl = "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=60",
                                        furnished = true,
                                        propertyType = "Apartment",
                                        neighborhood = "Gulshan",
                                        ownerName = "Mohammad Karim",
                                        ownerPhone = "+8801711223344",
                                        viewsCount = 112,
                                        isDraft = false,
                                        isApproved = true,
                                        promoType = "Featured",
                                        sellerType = "individual",
                                        subCategory = "Family",
                                        favoritesCount = 14,
                                        callsCount = 23,
                                        whatsappClicksCount = 41
                                    ),
                                    Property(
                                        id = "seed_p_pend_" + UUID.randomUUID().toString().take(4),
                                        title = "Commercial Office Space in Banani",
                                        slug = "seed-p-pend-2",
                                        description = "Ready brand new commercial floor plate perfect for tech startups or corporate corporate branches. Super fast elevator.",
                                        listingType = "rent",
                                        price = 85000.0,
                                        bedrooms = 0,
                                        bathrooms = 2,
                                        areaSqft = 1800,
                                        address = "Road 11, Banani",
                                        city = "Dhaka",
                                        featured = false,
                                        verified = false,
                                        audience = "corporate",
                                        imageUrl = "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&auto=format&fit=crop&q=60",
                                        furnished = false,
                                        propertyType = "Office Space",
                                        neighborhood = "Banani",
                                        ownerName = "Anisur Rahman",
                                        ownerPhone = "+8801819223344",
                                        viewsCount = 5,
                                        isDraft = false,
                                        isApproved = false, // Pending Review!
                                        sellerType = "agent",
                                        subCategory = "Corporate"
                                    ),
                                    Property(
                                        id = "seed_p_drf_" + UUID.randomUUID().toString().take(4),
                                        title = "[Draft] Cozy 1 Room Hostel Sublet",
                                        slug = "seed-p-drf-3",
                                        description = "Bachelor-friendly single master bed with attach bath and balcony in Dhanmondi. High speed internet.",
                                        listingType = "rent",
                                        price = 12000.0,
                                        bedrooms = 1,
                                        bathrooms = 1,
                                        areaSqft = 350,
                                        address = "Road 8/A, Dhanmondi",
                                        city = "Dhaka",
                                        featured = false,
                                        verified = false,
                                        audience = "bachelor",
                                        imageUrl = "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&auto=format&fit=crop&q=60",
                                        furnished = false,
                                        propertyType = "Hostel/Sublet",
                                        neighborhood = "Dhanmondi",
                                        ownerName = "Safwan Ahmed",
                                        ownerPhone = "+8801911998877",
                                        viewsCount = 0,
                                        isDraft = true, // Draft!
                                        isApproved = false,
                                        sellerType = "individual",
                                        subCategory = "Bachelor"
                                    )
                                )
                                seedProps.forEach { viewModel.addNewProperty(it) }
                                Toast.makeText(context, "System seeded with multi-state listings!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Filled.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Quick Seed", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Horizontal Category Tab Row for Dashboard List
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedDashboardTab,
                containerColor = Color.Transparent,
                edgePadding = 0.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedDashboardTab]),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            ) {
                dashboardTabs.forEachIndexed { idx, tabTitle ->
                    Tab(
                        selected = selectedDashboardTab == idx,
                        onClick = { selectedDashboardTab = idx },
                        text = {
                            Text(
                                text = tabTitle,
                                fontSize = 12.sp,
                                fontWeight = if (selectedDashboardTab == idx) FontWeight.ExtraBold else FontWeight.Bold,
                                color = if (selectedDashboardTab == idx) MaterialTheme.colorScheme.primary else Color.Gray
                            )
                        }
                    )
                }
            }
        }

        // Special Admin Review Desk Banner if on "Pending Review" tab
        if (selectedDashboardTab == 1) {
            val pendingCount = filteredDashboardList.size
            if (pendingCount > 0) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Filled.Gavel, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Text("Admin Vetting Queue Simulator", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("In a production app, our auditing team manually verifies deeds before publishing. For verification purposes, you can approve them immediately here:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f))
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    filteredDashboardList.forEach { p ->
                                        viewModel.approveListing(p.id)
                                    }
                                    Toast.makeText(context, "👑 Approved all pending listings successfully!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("Approve All (${pendingCount} Ads)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Empty state
        if (filteredDashboardList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(
                            imageVector = when (selectedDashboardTab) {
                                1 -> Icons.Filled.VerifiedUser
                                4 -> Icons.Filled.DriveFileRenameOutline
                                else -> Icons.Filled.Info
                            },
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "No listings found in the '${dashboardTabs[selectedDashboardTab]}' tab.",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(filteredDashboardList, key = { it.id }) { p ->
                val daysLeft = remember(p) {
                    val duration = 30 - ((System.currentTimeMillis() - p.timestamp) / (1000 * 60 * 60 * 24))
                    duration.coerceIn(0, 30).toInt()
                }
                val isExpired = daysLeft <= 0

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = p.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (p.promoType == "Featured") {
                                        Box(modifier = Modifier.clip(RoundedCornerShape(3.dp)).background(Color(0xFFE65100)).padding(horizontal = 4.dp, vertical = 1.dp)) {
                                            Text("Featured", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    } else if (p.promoType == "Urgent") {
                                        Box(modifier = Modifier.clip(RoundedCornerShape(3.dp)).background(Color(0xFFD32F2F)).padding(horizontal = 4.dp, vertical = 1.dp)) {
                                            Text("Urgent", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                                Text(
                                    text = "৳${p.price.toInt()} / month · ${p.neighborhood}",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Show badge depending on current status
                            val isExpired = daysLeft <= 0
                            val badgeBgColor = when {
                                p.isDraft -> Color.LightGray.copy(alpha = 0.3f)
                                p.isRented -> Color(0xFFD32F2F).copy(alpha = 0.12f)
                                !p.isApproved -> Color(0xFFE65100).copy(alpha = 0.12f)
                                isExpired -> Color(0xFFFFB300).copy(alpha = 0.12f)
                                else -> Color(0xFF388E3C).copy(alpha = 0.12f)
                            }
                            val badgeTextColor = when {
                                p.isDraft -> Color.DarkGray
                                p.isRented -> Color(0xFFD32F2F)
                                !p.isApproved -> Color(0xFFE65100)
                                isExpired -> Color(0xFFB78103)
                                else -> Color(0xFF388E3C)
                            }
                            val badgeLabel = when {
                                p.isDraft -> "Draft"
                                p.isRented -> "Rented/Sold"
                                !p.isApproved -> "Awaiting Vetting"
                                isExpired -> "Expired"
                                else -> "Live: $daysLeft days left"
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(badgeBgColor)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = badgeLabel,
                                    color = badgeTextColor,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Stats Dashboard Strip (Views, Favorites, Calls, WhatsApp)
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Filled.Visibility, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(13.dp))
                                Text("Views: ${p.viewsCount}", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Filled.Favorite, contentDescription = null, tint = Color.Red.copy(alpha = 0.6f), modifier = Modifier.size(13.dp))
                                Text("Likes: ${p.favoritesCount}", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Filled.Call, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(13.dp))
                                Text("Calls: ${p.callsCount}", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Filled.PhoneAndroid, contentDescription = null, tint = Color(0xFF388E3C), modifier = Modifier.size(13.dp))
                                Text("WhatsApp: ${p.whatsappClicksCount}", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Actions Row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (p.isDraft) {
                                Button(
                                    onClick = { loadDraftToWizard(p) },
                                    modifier = Modifier.weight(1.5f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(Icons.Filled.DriveFileRenameOutline, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Resume Draft", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                // Toggle Rented/Sold Status
                                Button(
                                    onClick = {
                                        viewModel.toggleRentedStatus(p.id, p.isRented)
                                        val msg = if (p.isRented) "Ad is live again!" else "Listing marked as Sold/Rented!"
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.weight(1.3f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (p.isRented) Color(0xFF388E3C) else Color(0xFFE0E0E0),
                                        contentColor = if (p.isRented) Color.White else Color.Black
                                    ),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(
                                        imageVector = if (p.isRented) Icons.Filled.CheckCircle else Icons.Filled.HighlightOff,
                                        contentDescription = null,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (p.isRented) "Set Active" else "Mark Rented", fontSize = 11.sp)
                                }

                                // Edit Price Button
                                OutlinedButton(
                                    onClick = {
                                        showEditPriceDialog = p
                                        newPriceText = p.price.toInt().toString()
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Edit Rent", fontSize = 11.sp)
                                }

                                // Renew Button if Expired or close to expiration
                                if (isExpired) {
                                    Button(
                                        onClick = {
                                            viewModel.renewListing(p.id)
                                            Toast.makeText(context, "🔄 Listing renewed successfully for another 30 days!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.weight(1.1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Icon(Icons.Filled.Autorenew, contentDescription = null, modifier = Modifier.size(13.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Renew", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Admin simulation: single click approval button for testability
                                if (!p.isApproved) {
                                    IconButton(
                                        onClick = {
                                            viewModel.approveListing(p.id)
                                            Toast.makeText(context, "👑 Ad Approved!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(36.dp),
                                        colors = IconButtonDefaults.filledIconButtonColors(
                                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                            contentColor = MaterialTheme.colorScheme.primary
                                        )
                                    ) {
                                        Icon(Icons.Filled.Gavel, contentDescription = "Approve Listing", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            // Delete Listing Button
                            IconButton(
                                onClick = {
                                    viewModel.deleteProperty(p.id)
                                    Toast.makeText(context, "Listing deleted permanently.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(36.dp),
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = Color(0xFFFFEBEE),
                                    contentColor = Color(0xFFD32F2F)
                                )
                            ) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Edit Price Dialog
    if (showEditPriceDialog != null) {
        AlertDialog(
            onDismissRequest = { showEditPriceDialog = null },
            title = { Text("Modify Rent Pricing", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Update rent value for: ${showEditPriceDialog?.title}", fontSize = 12.sp, color = Color.Gray)
                    OutlinedTextField(
                        value = newPriceText,
                        onValueChange = { newPriceText = it },
                        label = { Text("Rent Value BDT") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val priceNum = newPriceText.toDoubleOrNull()
                        if (priceNum != null && priceNum > 0 && showEditPriceDialog != null) {
                            val updated = showEditPriceDialog!!.copy(price = priceNum)
                            viewModel.addNewProperty(updated)
                            showEditPriceDialog = null
                            Toast.makeText(context, "Pricing updated successfully!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Please input a valid price.", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPriceDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Stateful Multi-step "Post an Ad" Fullscreen Wizard Dialog
    if (showAddDialog) {
        Dialog(
            onDismissRequest = { 
                // Do not dismiss automatically to avoid losing inputs, save draft instead!
            }
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 12.dp, horizontal = 4.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.background,
                tonalElevation = 6.dp
            ) {
                // Outer Step Container
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    // Wizard Header / Step progress Indicator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(onClick = {
                            saveCurrentAsDraft()
                        }) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = "Save Draft", tint = MaterialTheme.colorScheme.secondary)
                        }
                        
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Post Ad Wizard",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Step $wizardStep of 8 · ${
                                    when(wizardStep) {
                                        1 -> "Category & Structure"
                                        2 -> "Property Specifications"
                                        3 -> "Interactive Location"
                                        4 -> "Photos Upload"
                                        5 -> "Seller Accounts"
                                        6 -> "Duplicate Screening"
                                        7 -> "OTP SMS Check"
                                        else -> "Promotion Boost"
                                    }
                                }",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        IconButton(onClick = {
                            showAddDialog = false
                            resetWizardFields()
                        }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.Gray)
                        }
                    }

                    // Linear Step Indicator Bar
                    LinearProgressIndicator(
                        progress = { wizardStep / 8f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = Color.LightGray.copy(alpha = 0.3f)
                    )

                    // Step Contents Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        when (wizardStep) {
                            1 -> {
                                // Step 1: Category Selection
                                val categoriesList = listOf("Apartment", "House", "Land", "Commercial", "Office", "Shop", "Hostel", "Garage")
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text("Select Property Category", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    
                                    // 2x4 category grid
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        categoriesList.chunked(2).forEach { rowList ->
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                rowList.forEach { cat ->
                                                    val isSel = wizardCategory == cat
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(8.dp))
                                                            .border(1.dp, if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray, RoundedCornerShape(8.dp))
                                                            .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent)
                                                            .clickable { wizardCategory = cat }
                                                            .padding(14.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(cat, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (isSel) MaterialTheme.colorScheme.primary else Color.DarkGray)
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Category Sub-filter audience", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    val subs = when (wizardCategory) {
                                        "Apartment", "House", "Hostel" -> listOf("Family", "Bachelor", "Female-only", "Sublet")
                                        "Office", "Commercial", "Shop" -> listOf("Corporate", "Coworking", "Private", "Shared")
                                        else -> listOf("Residential", "Commercial")
                                    }
                                    
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        subs.forEach { s ->
                                            val isSel = wizardSubCategory == s
                                            FilterChip(
                                                selected = isSel,
                                                onClick = { wizardSubCategory = s },
                                                label = { Text(s, fontSize = 11.sp) }
                                            )
                                        }
                                    }
                                }
                            }

                            2 -> {
                                // Step 2: Property Specifications Details
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Tell us about your property", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    
                                    OutlinedTextField(
                                        value = wizardTitle,
                                        onValueChange = { wizardTitle = it },
                                        label = { Text("Listing Title (Min 5 chars)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = wizardPrice,
                                            onValueChange = { wizardPrice = it },
                                            label = { Text("Monthly Rent BDT") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )

                                        OutlinedTextField(
                                            value = wizardSizeSqft,
                                            onValueChange = { wizardSizeSqft = it },
                                            label = { Text("Size (Sqft)") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                    }

                                    // AI PRICE RECOMMENDATION BUTTON
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (aiPriceLoading) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("AI analyzing local rental indexes...", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        } else {
                                            TextButton(
                                                onClick = {
                                                    aiPriceLoading = true
                                                    scope.launch {
                                                        val rec = com.example.ui.GeminiHelper.suggestPrice(
                                                            category = wizardCategory,
                                                            neighborhood = wizardNeighborhood,
                                                            bedrooms = wizardBedrooms.toIntOrNull() ?: 2,
                                                            bathrooms = wizardBathrooms.toIntOrNull() ?: 2,
                                                            areaSqft = wizardSizeSqft.toIntOrNull() ?: 1200
                                                        )
                                                        aiPriceRecommendation = rec
                                                        // Extract numeric BDT value from Gemini output text
                                                        val numberMatches = "\\d+".toRegex().findAll(rec.replace(",", "")).map { it.value }.toList()
                                                        val possibleValue = numberMatches.firstOrNull { it.toInt() > 3000 }
                                                        suggestedRentAmount = possibleValue ?: ""
                                                        aiPriceLoading = false
                                                        showAiPriceDialog = true
                                                    }
                                                }
                                            ) {
                                                Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(13.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("🤖 AI Recommend Rent Price", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        OutlinedTextField(
                                            value = wizardBedrooms,
                                            onValueChange = { wizardBedrooms = it },
                                            label = { Text("Bedrooms") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                        OutlinedTextField(
                                            value = wizardBathrooms,
                                            onValueChange = { wizardBathrooms = it },
                                            label = { Text("Bathrooms") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                        OutlinedTextField(
                                            value = wizardFloorNumber,
                                            onValueChange = { wizardFloorNumber = it },
                                            label = { Text("Floor #") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier.weight(1f),
                                            singleLine = true
                                        )
                                    }

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Checkbox(checked = wizardFurnished, onCheckedChange = { wizardFurnished = it })
                                        Text("This property is fully furnished", fontSize = 12.sp)
                                    }

                                    // AI GENERATE DESCRIPTION CARD WIDGET
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f))
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                                Text("Generate Professional Ad Description with AI", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            }
                                            OutlinedTextField(
                                                value = aiDescriptionKeywords,
                                                onValueChange = { aiDescriptionKeywords = it },
                                                placeholder = { Text("E.g., north-facing, water backup, 2 mins from Metro", fontSize = 11.sp) },
                                                label = { Text("Type short features / points", fontSize = 10.sp) },
                                                modifier = Modifier.fillMaxWidth(),
                                                singleLine = true
                                            )
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End
                                            ) {
                                                if (aiDescriptionLoading) {
                                                    CircularProgressIndicator(modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("AI generating descriptive text...", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                                } else {
                                                    TextButton(
                                                        onClick = {
                                                            aiDescriptionLoading = true
                                                            scope.launch {
                                                                val desc = com.example.ui.GeminiHelper.generatePropertyDescription(
                                                                    bullets = aiDescriptionKeywords,
                                                                    category = wizardCategory,
                                                                    neighborhood = wizardNeighborhood
                                                                )
                                                                wizardDescription = desc
                                                                aiDescriptionLoading = false
                                                                Toast.makeText(context, "✨ AI generated successfully!", Toast.LENGTH_SHORT).show()
                                                            }
                                                        },
                                                        enabled = aiDescriptionKeywords.isNotBlank()
                                                    ) {
                                                        Text("🤖 Draft Ad Copy", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = wizardDescription,
                                        onValueChange = { wizardDescription = it },
                                        label = { Text("Detailed Description (Optional)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        minLines = 3
                                    )

                                    // POPUP DIALOG FOR AI PRICE ESTIMATE ANALYSIS
                                    if (showAiPriceDialog) {
                                        AlertDialog(
                                            onDismissRequest = { showAiPriceDialog = false },
                                            title = {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                                    Text("Gemini Rent Recommendation", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                                }
                                            },
                                            text = {
                                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Text(aiPriceRecommendation, fontSize = 12.sp, lineHeight = 16.sp)
                                                    if (suggestedRentAmount.isNotBlank()) {
                                                        Divider(color = Color.LightGray.copy(alpha = 0.3f))
                                                        Text("Suggested Price: ৳$suggestedRentAmount BDT / month", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                                    }
                                                }
                                            },
                                            confirmButton = {
                                                if (suggestedRentAmount.isNotBlank()) {
                                                    Button(
                                                        onClick = {
                                                            wizardPrice = suggestedRentAmount
                                                            showAiPriceDialog = false
                                                            Toast.makeText(context, "Price updated to ৳$suggestedRentAmount", Toast.LENGTH_SHORT).show()
                                                        }
                                                    ) {
                                                        Text("Apply ৳$suggestedRentAmount")
                                                    }
                                                }
                                            },
                                            dismissButton = {
                                                TextButton(onClick = { showAiPriceDialog = false }) {
                                                    Text("Dismiss")
                                                }
                                            }
                                        )
                                    }
                                }
                            }

                            3 -> {
                                // Step 3: Location mapping
                                val neighborhoods = listOf("Gulshan", "Banani", "Dhanmondi", "Uttara", "Bashundhara", "Mirpur")
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Set Property Location", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    
                                    // Neighborhood selector dropdown
                                    Text("Select Area:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                                    ) {
                                        neighborhoods.forEach { area ->
                                            val isSel = wizardNeighborhood == area
                                            FilterChip(
                                                selected = isSel,
                                                onClick = { wizardNeighborhood = area },
                                                label = { Text(area, fontSize = 11.sp) }
                                            )
                                        }
                                    }

                                    OutlinedTextField(
                                        value = wizardAddress,
                                        onValueChange = { wizardAddress = it },
                                        label = { Text("Exact Address / Road / House Number") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )

                                    // Interactive Dhaka Map Pin Drop Simulation Canvas
                                    Text("Map Pin Drop Simulation (Tap to drop pin):", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(140.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFFE0F2F1))
                                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                            .pointerInput(Unit) {
                                                detectTapGestures { offset ->
                                                    isMapPinDropped = true
                                                    // Map coordinates roughly to mock lat/long
                                                    wizardLatitude = 23.7000 + (offset.y / 1000)
                                                    wizardLongitude = 90.3500 + (offset.x / 1000)
                                                }
                                            }
                                    ) {
                                        // Draw beautiful grid map lines
                                        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceEvenly) {
                                            repeat(3) { Divider(color = Color.White.copy(alpha = 0.7f), thickness = 2.dp) }
                                        }
                                        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                            repeat(4) { Box(modifier = Modifier.fillMaxHeight().width(2.dp).background(Color.White.copy(alpha = 0.7f))) }
                                        }

                                        // Landmarks mock names
                                        Text("Gulshan Lake", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(top = 20.dp, start = 30.dp))
                                        Text("Banani Road 11", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(top = 80.dp, start = 120.dp))
                                        Text("Dhanmondi Lake", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(top = 110.dp, start = 20.dp))

                                        // Conditional dropped pin
                                        if (isMapPinDropped) {
                                            Icon(
                                                imageVector = Icons.Filled.LocationOn,
                                                contentDescription = "Map Pin",
                                                tint = Color.Red,
                                                modifier = Modifier
                                                    .align(Alignment.Center)
                                                    .size(36.dp)
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.BottomCenter)
                                                    .background(Color.Black.copy(alpha = 0.6f))
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text("Lat: ${String.format("%.4f", wizardLatitude)} · Lon: ${String.format("%.4f", wizardLongitude)}", color = Color.White, fontSize = 9.sp)
                                            }
                                        } else {
                                            Text(
                                                text = "📍 Tap anywhere on this map to place pin",
                                                color = MaterialTheme.colorScheme.primary,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.align(Alignment.Center)
                                            )
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            isMapPinDropped = true
                                            wizardLatitude = 23.7937
                                            wizardLongitude = 90.4066
                                            Toast.makeText(context, "📍 Auto-detected GPS at Gulshan Circle 2", Toast.LENGTH_SHORT).show()
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Filled.MyLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Auto-Detect GPS Location via Maps")
                                    }
                                }
                            }

                            4 -> {
                                // Step 4: Photo upload with Minimum 3 Verification Rule
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Upload Property Photos", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Rentnin verification protocols require a minimum of 3 real, non-watermarked property images to curb fraudulent broker listings.", color = Color.Gray, fontSize = 11.sp, lineHeight = 14.sp)
                                    
                                    Text("Select at least 3 photos below (${selectedPhotos.size}/3 selected):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (selectedPhotos.size >= 3) Color(0xFF388E3C) else Color(0xFFD32F2F))

                                    // Display photo choices
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        photoOptions.chunked(2).forEach { rowPhotos ->
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                rowPhotos.forEach { (url, label) ->
                                                    val isSel = selectedPhotos.contains(url)
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(100.dp)
                                                            .clip(RoundedCornerShape(8.dp))
                                                            .border(
                                                                width = if (isSel) 3.dp else 1.dp,
                                                                color = if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray,
                                                                shape = RoundedCornerShape(8.dp)
                                                            )
                                                            .clickable {
                                                                selectedPhotos = if (isSel) selectedPhotos - url else selectedPhotos + url
                                                            }
                                                    ) {
                                                        AsyncImage(
                                                            model = url,
                                                            contentDescription = null,
                                                            modifier = Modifier.fillMaxSize(),
                                                            contentScale = ContentScale.Crop
                                                        )
                                                        
                                                        // Tick icon overlay
                                                        if (isSel) {
                                                            Box(
                                                                modifier = Modifier
                                                                    .fillMaxSize()
                                                                    .background(Color.Black.copy(alpha = 0.3f))
                                                            )
                                                            Icon(
                                                                imageVector = Icons.Filled.CheckCircle,
                                                                contentDescription = "Selected",
                                                                tint = Color.White,
                                                                modifier = Modifier
                                                                    .align(Alignment.Center)
                                                                    .size(28.dp)
                                                            )
                                                        }

                                                        Box(
                                                            modifier = Modifier
                                                                .align(Alignment.BottomCenter)
                                                                .fillMaxWidth()
                                                                .background(Color.Black.copy(alpha = 0.5f))
                                                                .padding(2.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(label, color = Color.White, fontSize = 9.sp, maxLines = 1)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            5 -> {
                                // Step 5: Seller details & Seller type selection
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Seller Profile Details", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Distinguish your account type on Rentnin to customize badges. Owners get 'Direct Landlord' status while brokers receive 'Agency Representative' tag.", color = Color.Gray, fontSize = 11.sp, lineHeight = 14.sp)

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        val types = listOf("Individual", "Agent")
                                        types.forEach { t ->
                                            val isSel = wizardSellerType == t
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.2f))
                                                    .clickable { wizardSellerType = t }
                                                    .padding(12.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Icon(
                                                        imageVector = if (t == "Individual") Icons.Filled.Person else Icons.Filled.SupportAgent,
                                                        contentDescription = null,
                                                        tint = if (isSel) Color.White else Color.Black,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Text(
                                                        text = if (t == "Individual") "Landlord Owner" else "Agency Agent",
                                                        color = if (isSel) Color.White else Color.Black,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    OutlinedTextField(
                                        value = wizardSellerName,
                                        onValueChange = { wizardSellerName = it },
                                        label = { Text("Contact Name (Mandatory)") },
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )

                                    OutlinedTextField(
                                        value = wizardSellerPhone,
                                        onValueChange = { wizardSellerPhone = it },
                                        label = { Text("Contact Phone (e.g. +8801700...)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                        modifier = Modifier.fillMaxWidth(),
                                        singleLine = true
                                    )
                                }
                            }

                            6 -> {
                                // Step 6: Automated Duplicate Listing screening
                                val isDuplicateFound = properties.any { p ->
                                    !p.isDraft && p.ownerPhone == wizardSellerPhone && p.address.equals(wizardAddress, ignoreCase = true)
                                }
                                var confirmUniqueCheckbox by remember { mutableStateOf(false) }

                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Security Listing Vetting Screen", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    
                                    if (isDuplicateFound) {
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                                            modifier = Modifier.fillMaxWidth(),
                                            border = BorderStroke(1.dp, Color(0xFFD32F2F))
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Icon(Icons.Filled.Warning, contentDescription = null, tint = Color(0xFFD32F2F))
                                                    Text("DUPLICATE ADS DETECTED!", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFFD32F2F))
                                                }
                                                Text("Our security logs show that an ad with this phone number ($wizardSellerPhone) at this exact address ($wizardAddress) already exists in Dhanmondi. Rentnin has a zero-tolerance policy for spam duplication or agency listing hijackers.", fontSize = 11.sp, color = Color.DarkGray)
                                            }
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Checkbox(checked = confirmUniqueCheckbox, onCheckedChange = { confirmUniqueCheckbox = it })
                                            Text("This is a distinct unit/floor inside the same holding building", fontSize = 11.sp, color = Color.Red, fontWeight = FontWeight.Bold)
                                        }

                                        // Inject confirmation into verified flow
                                        LaunchedEffect(confirmUniqueCheckbox) {
                                            otpVerified = confirmUniqueCheckbox
                                        }
                                    } else {
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                                            modifier = Modifier.fillMaxWidth(),
                                            border = BorderStroke(1.dp, Color(0xFF388E3C))
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF388E3C))
                                                    Text("Unique Listing Verified", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF388E3C))
                                                }
                                                Text("Automated system checks finished. No matching phone and address duplicates discovered. Your listing is safe to publish.", fontSize = 11.sp, color = Color.DarkGray)
                                            }
                                        }
                                        
                                        // Auto-verify if no duplicate
                                        LaunchedEffect(Unit) {
                                            otpVerified = true
                                        }
                                    }

                                    // Display preview details
                                    Text("Review specifications before proceeding:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("🏡 Title: $wizardTitle", fontSize = 11.sp)
                                            Text("💰 BDT Rent: ৳$wizardPrice", fontSize = 11.sp)
                                            Text("📍 Location: $wizardAddress, $wizardNeighborhood", fontSize = 11.sp)
                                            Text("👤 Seller: $wizardSellerName ($wizardSellerType)", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }

                            7 -> {
                                // Step 7: Phone verification via SMS OTP simulation
                                var timer by remember { mutableStateOf(30) }
                                
                                LaunchedEffect(otpMessageTriggered) {
                                    if (otpMessageTriggered) {
                                        generatedOtp = "4892" // Static realistic OTP for verification simulation
                                        Toast.makeText(context, "💬 SMS Broadcast Sent to $wizardSellerPhone", Toast.LENGTH_SHORT).show()
                                        while(timer > 0) {
                                            delay(1000)
                                            timer--
                                        }
                                    }
                                }

                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("Mobile Phone OTP Verification", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.align(Alignment.Start))
                                    Text("Rentnin validates landlord contact authenticity by requesting a 1-shot SMS confirmation. Click the broadcast button below to request code.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.Start))

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Interactive SMS notification simulator popup banner
                                    if (otpMessageTriggered) {
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = Color.Black),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 4.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                Icon(Icons.Filled.Sms, contentDescription = null, tint = Color.Green)
                                                Column {
                                                    Text("SMS from RENTNIN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                    Text("Your Rentnin verification code is: $generatedOtp. Valid for 5 minutes.", color = Color.LightGray, fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    OutlinedTextField(
                                        value = otpInput,
                                        onValueChange = { 
                                            otpInput = it
                                            if (it == "4892") {
                                                otpVerified = true
                                                Toast.makeText(context, "✅ Phone Number Verified Successfully!", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        label = { Text("Enter 4-Digit OTP Code") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.width(200.dp),
                                        singleLine = true,
                                        textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center)
                                    )

                                    if (otpVerified) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Filled.Verified, contentDescription = null, tint = Color(0xFF388E3C))
                                            Text("Phone number has been verified!", color = Color(0xFF388E3C), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    } else {
                                        Button(
                                            onClick = {
                                                otpMessageTriggered = true
                                                timer = 30
                                            },
                                            enabled = !otpMessageTriggered || timer <= 0,
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(if (otpMessageTriggered) "Resend SMS in (${timer}s)" else "BroadCast SMS verification OTP", fontSize = 12.sp)
                                        }
                                        Text("Please type '4892' to simulate successful OTP handshake.", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            else -> {
                                // Step 8: Monetization / Promoted Listings package selection
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("Maximize Views with Premium Boosts", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Sellers who boost listings receive up to 8x higher lead clicks and automated WhatsApp reach on our home page feeds.", color = Color.Gray, fontSize = 11.sp, lineHeight = 14.sp)

                                    // Display 3 Promotion Packages
                                    val packages = listOf(
                                        Triple("Free", "৳0 · Normal listing duration", "Standard organic catalog views. Manual vetting queue."),
                                        Triple("Featured", "৳499 · 30 Days Pinned Placement", "Stays highlighted in search feed top tiers. Direct green badge."),
                                        Triple("Urgent", "৳999 · 30 Days Red Urgent Label", "Highest visibility, urgent labels, prioritized SMS leads.")
                                    )

                                    packages.forEach { (type, cost, benefits) ->
                                        val isSel = selectedPromoType == type
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .border(
                                                    width = if (isSel) 2.dp else 1.dp,
                                                    color = if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.5f),
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                                .clickable { 
                                                    selectedPromoType = type 
                                                    if (type == "Free") promoPaid = false
                                                },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.04f) else Color.White
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                RadioButton(selected = isSel, onClick = { 
                                                    selectedPromoType = type
                                                    if (type == "Free") promoPaid = false
                                                })
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(type, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = if (isSel) MaterialTheme.colorScheme.primary else Color.Black)
                                                    Text(cost, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                                    Text(benefits, fontSize = 10.sp, color = Color.Gray, lineHeight = 12.sp)
                                                }
                                            }
                                        }
                                    }

                                    // Simulated bKash transaction drawer if Featured or Urgent is clicked
                                    if (selectedPromoType != "Free") {
                                        if (promoPaid) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color(0xFFE8F5E9))
                                                    .padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(Icons.Filled.Verified, contentDescription = null, tint = Color(0xFF388E3C))
                                                Text("bKash Payment Successful! Promotion Package Cleared.", fontSize = 11.sp, color = Color(0xFF388E3C), fontWeight = FontWeight.Bold)
                                            }
                                        } else {
                                            Button(
                                                onClick = { 
                                                    showBkashCheckout = true 
                                                    bkashCheckoutStep = 1
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2136E)), // bKash official color
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Filled.Payment, contentDescription = null, tint = Color.White)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Pay with bKash Checkout Wallet", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Bottom Navigation Buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (wizardStep > 1) {
                            OutlinedButton(
                                onClick = { wizardStep-- },
                                shape = RoundedCornerShape(24.dp)
                            ) {
                                Text("Back")
                            }
                        } else {
                            TextButton(onClick = { saveCurrentAsDraft() }) {
                                Icon(Icons.Filled.FolderZip, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save Draft", fontWeight = FontWeight.Bold)
                            }
                        }

                        Button(
                            onClick = {
                                if (wizardStep == 1) {
                                    wizardStep = 2
                                } else if (wizardStep == 2) {
                                    if (wizardTitle.isBlank() || wizardPrice.isBlank() || wizardSizeSqft.isBlank()) {
                                        Toast.makeText(context, "Please complete Title, Price, and Size sqft.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        wizardStep = 3
                                    }
                                } else if (wizardStep == 3) {
                                    if (wizardAddress.isBlank()) {
                                        Toast.makeText(context, "Please enter an address location.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        wizardStep = 4
                                    }
                                } else if (wizardStep == 4) {
                                    if (selectedPhotos.size < 3) {
                                        Toast.makeText(context, "⚠️ Rentnin requires at least 3 photos to publish.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        wizardStep = 5
                                    }
                                } else if (wizardStep == 5) {
                                    if (wizardSellerName.isBlank() || wizardSellerPhone.isBlank()) {
                                        Toast.makeText(context, "Seller Name and Phone are required.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        wizardStep = 6
                                    }
                                } else if (wizardStep == 6) {
                                    // Duplicate check verification
                                    val isDuplicate = properties.any { p ->
                                        !p.isDraft && p.ownerPhone == wizardSellerPhone && p.address.equals(wizardAddress, ignoreCase = true)
                                    }
                                    if (isDuplicate && !otpVerified) {
                                        Toast.makeText(context, "⚠️ Please review duplicate listing screening checkboxes.", Toast.LENGTH_LONG).show()
                                    } else {
                                        wizardStep = 7
                                    }
                                } else if (wizardStep == 7) {
                                    if (!otpVerified) {
                                        Toast.makeText(context, "⚠️ OTP verification failed. Enter code '4892'.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        wizardStep = 8
                                    }
                                } else {
                                    // Final Publish!
                                    if (selectedPromoType != "Free" && !promoPaid) {
                                        Toast.makeText(context, "⚠️ Please complete bKash billing payment first or select 'Free'.", Toast.LENGTH_LONG).show()
                                    } else {
                                        val newId = draftIdBeingEdited ?: ("p_" + UUID.randomUUID().toString().take(6))
                                        val promoApplied = selectedPromoType
                                        
                                        val finalizedProperty = Property(
                                            id = newId,
                                            title = wizardTitle,
                                            slug = wizardTitle.lowercase().replace(" ", "-") + "-" + newId,
                                            description = wizardDescription.ifBlank { "Beautiful $wizardCategory located in $wizardNeighborhood." },
                                            listingType = "rent",
                                            price = wizardPrice.toDoubleOrNull() ?: 30000.0,
                                            bedrooms = wizardBedrooms.toIntOrNull() ?: 2,
                                            bathrooms = wizardBathrooms.toIntOrNull() ?: 2,
                                            areaSqft = wizardSizeSqft.toIntOrNull() ?: 1200,
                                            address = wizardAddress,
                                            city = "Dhaka",
                                            featured = promoApplied == "Featured" || promoApplied == "Urgent",
                                            verified = wizardSellerType == "Individual",
                                            audience = wizardSubCategory.lowercase(),
                                            imageUrl = selectedPhotos.firstOrNull() ?: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&auto=format&fit=crop&q=60",
                                            additionalImages = selectedPhotos.drop(1).joinToString(","),
                                            furnished = wizardFurnished,
                                            propertyType = wizardCategory,
                                            neighborhood = wizardNeighborhood,
                                            ownerName = wizardSellerName,
                                            ownerPhone = wizardSellerPhone,
                                            viewsCount = 0,
                                            isDraft = false, // Not draft anymore!
                                            isApproved = false, // Awaiting admin vetting
                                            promoType = if (promoApplied != "Free") promoApplied else "",
                                            sellerType = wizardSellerType.lowercase(),
                                            subCategory = wizardSubCategory
                                        )

                                        viewModel.addNewProperty(finalizedProperty)
                                        showAddDialog = false
                                        resetWizardFields()
                                        selectedDashboardTab = 1 // Switch to pending review tab!
                                        Toast.makeText(context, "🎉 Ad Posted! Undergoing automatic vetting checks in pending reviews.", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            shape = RoundedCornerShape(24.dp),
                            enabled = when (wizardStep) {
                                4 -> selectedPhotos.size >= 3
                                7 -> otpVerified
                                else -> true
                            }
                        ) {
                            Text(if (wizardStep == 8) "Publish Ad" else "Next")
                        }
                    }
                }
            }
        }
    }

    // Official bKash Gateway Wallet Payment Simulation Dialog
    if (showBkashCheckout) {
        AlertDialog(
            onDismissRequest = { showBkashCheckout = false },
            title = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFE2136E)) // bKash official pink
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("bKash Merchant Payment Gateway", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Merchant: Rentnin Property Ltd\nAmount Due: BDT ${if (selectedPromoType == "Featured") "499.00" else "999.00"}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )

                    when (bkashCheckoutStep) {
                        1 -> {
                            Text("Enter your bKash wallet number to initiate payment secure handshake:", fontSize = 11.sp, color = Color.Gray)
                            OutlinedTextField(
                                value = bkashWalletNumber,
                                onValueChange = { bkashWalletNumber = it },
                                placeholder = { Text("017XXXXXXXX") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        2 -> {
                            Text("A simulated 6-digit transaction OTP has been sent via SMS. Enter it below:", fontSize = 11.sp, color = Color.Gray)
                            OutlinedTextField(
                                value = bkashOtpInput,
                                onValueChange = { bkashOtpInput = it },
                                placeholder = { Text("Enter OTP (e.g. 581903)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center)
                            )
                            Text("Please type '581903' to pass verification.", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                        3 -> {
                            Text("Confirm payment secure loop by typing your 5-digit PIN:", fontSize = 11.sp, color = Color.Gray)
                            OutlinedTextField(
                                value = bkashPinInput,
                                onValueChange = { bkashPinInput = it },
                                label = { Text("bKash Pin Code") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (bkashCheckoutStep == 1) {
                            if (bkashWalletNumber.length < 11) {
                                Toast.makeText(context, "Please enter valid 11-digit wallet number.", Toast.LENGTH_SHORT).show()
                            } else {
                                bkashCheckoutStep = 2
                                Toast.makeText(context, "bKash SMS OTP broadcasted!", Toast.LENGTH_SHORT).show()
                            }
                        } else if (bkashCheckoutStep == 2) {
                            if (bkashOtpInput != "581903") {
                                Toast.makeText(context, "Incorrect bKash OTP handshake code.", Toast.LENGTH_SHORT).show()
                            } else {
                                bkashCheckoutStep = 3
                            }
                        } else if (bkashCheckoutStep == 3) {
                            if (bkashPinInput.length < 4) {
                                Toast.makeText(context, "Please enter valid pin digits.", Toast.LENGTH_SHORT).show()
                            } else {
                                promoPaid = true
                                showBkashCheckout = false
                                Toast.makeText(context, "💸 bKash billing success! Promotion features unlocked.", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2136E))
                ) {
                    Text("Confirm Proceed", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBkashCheckout = false }) {
                    Text("Cancel Transaction", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun ContactRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, fontSize = 12.sp, color = Color.Gray)
        }
        Icon(
            imageVector = Icons.Filled.ChevronRight,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(16.dp)
        )
    }
}
