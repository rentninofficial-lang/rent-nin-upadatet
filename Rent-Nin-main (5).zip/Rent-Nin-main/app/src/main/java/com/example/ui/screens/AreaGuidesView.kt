package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@Composable
fun AreaGuidesView(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val neighborhoods = listOf("Gulshan", "Banani", "Dhanmondi", "Uttara", "Bashundhara", "Mirpur", "Motijheel")
    var selectedArea by remember { mutableStateOf("Gulshan") }

    // Hardcoded rich statistics of neighborhoods for area guide
    val schoolList = when (selectedArea) {
        "Gulshan" -> listOf("Scholastica School", "AISD (American International School)", "Manarat Dhaka School")
        "Banani" -> listOf("South Breeze School", "Banani International School", "International School Dhaka")
        "Dhanmondi" -> listOf("Mastermind School", "Sunbeams School", "Maple Leaf International")
        "Uttara" -> listOf("Aga Khan School", "Milestone College", "RAJUK Uttara Model College")
        "Bashundhara" -> listOf("International School Dhaka (ISD)", "Hurdco School", "Playpen School")
        "Mirpur" -> listOf("SOS Hermann Gmeiner School", "Monipur High School", "BCIC College")
        "Motijheel" -> listOf("Ideal School & College", "Notre Dame College", "Motijheel Government High School")
        else -> listOf("Local Standard Schools", "Area Kindergarten Academy")
    }

    val hospitalList = when (selectedArea) {
        "Gulshan" -> listOf("United Hospital Ltd.", "Shin Shin Hospital", "Cure Medical Center")
        "Banani" -> listOf("Praava Health", "Banani Clinic", "Green Life Medical Banani")
        "Dhanmondi" -> listOf("Labaid Specialized Hospital", "Bangladesh Medical College Hospital", "Ibn Sina Hospital")
        "Uttara" -> listOf("Kuwait Bangladesh Friendship Hospital", "Uttara Crescent Hospital", "Aichi Hospital")
        "Bashundhara" -> listOf("Evercare Hospital Dhaka", "D-Akbar Hospital", "Vip Healthcare Center")
        "Mirpur" -> listOf("National Heart Foundation Hospital", "Kidney Foundation", "Mirpur General Hospital")
        "Motijheel" -> listOf("Islami Bank Hospital Motijheel", "Central Government Hospital", "Kamalapur Railway Hospital")
        else -> listOf("Local Health Clinic", "Standard Pharmacy Care")
    }

    val transportList = when (selectedArea) {
        "Gulshan" -> listOf("Gulshan Circle 1 & 2 Bus Bays", "Lake Water Taxi service", "Gulshan-Banani Link Road")
        "Banani" -> listOf("Banani Kakoli Crossing", "Banani Railway Station", "Dhaka Metro Rail (Shewrapara Access)")
        "Dhanmondi" -> listOf("Satmasjid Road Bus Terminus", "Mirpur Road Bus corridor", "Farmgate Metro Station link")
        "Uttara" -> listOf("Uttara North Metro Station", "Uttara Center Metro Station", "Hazrat Shahjalal Airport corridor")
        "Bashundhara" -> listOf("Kuril Flyover bus terminal", "Bashundhara Main Gate transit", "300 Feet Road express")
        "Mirpur" -> listOf("Mirpur 10 Metro Rail Station", "Mirpur 11 Metro Station", "Gabtoli Inter-district Terminal")
        "Motijheel" -> listOf("Kamalapur Central Railway Station", "Motijheel Metro Station", "BRTC central double-decker bay")
        else -> listOf("Local Rickshaw corridors", "Standard CNG taxi stands")
    }

    val rentTrends = when (selectedArea) {
        "Gulshan" -> listOf(65000, 70000, 75000, 80000, 85000)
        "Banani" -> listOf(58000, 62000, 66000, 71000, 75000)
        "Dhanmondi" -> listOf(38000, 40000, 42000, 44000, 45000)
        "Uttara" -> listOf(24000, 26000, 29000, 32000, 35000) // Huge metro rail rise!
        "Bashundhara" -> listOf(22000, 23500, 25000, 26500, 28000)
        "Mirpur" -> listOf(15000, 16500, 18000, 20000, 22000) // Huge metro rise!
        "Motijheel" -> listOf(58000, 57000, 56000, 55000, 55000) // Minor dip due to office migration
        else -> listOf(20000, 21000, 22000, 23000, 24000)
    }

    val securityGrade = when (selectedArea) {
        "Gulshan" -> "Grade A+ (CCTV, Diplomatic Guards, Gate Barriers)"
        "Banani" -> "Grade A (Police Patrol, Active Neighborhood Watch)"
        "Dhanmondi" -> "Grade B+ (Secured building gates, standard patrols)"
        "Uttara" -> "Grade B+ (Private guards, Metro Security corridor)"
        "Bashundhara" -> "Grade A (Gated Entry checkpoints, 24/7 Security)"
        "Mirpur" -> "Grade B (Standard secure residential guidelines)"
        "Motijheel" -> "Grade B (High commercial patrols, busy corridors)"
        else -> "Grade B (Standard Security)"
    }

    // Commute Estimator States
    var destination by remember { mutableStateOf("Motijheel") }
    var transportMode by remember { mutableStateOf("Metro Rail") }

    // Distance calculation logic (approx BDT calculations in km)
    val distanceKm = when {
        selectedArea == destination -> 1.5
        selectedArea == "Uttara" && destination == "Motijheel" -> 18.0
        selectedArea == "Uttara" && destination == "Gulshan" -> 11.5
        selectedArea == "Mirpur" && destination == "Motijheel" -> 12.0
        selectedArea == "Mirpur" && destination == "Gulshan" -> 8.5
        selectedArea == "Gulshan" && destination == "Motijheel" -> 6.5
        selectedArea == "Gulshan" && destination == "Uttara" -> 11.5
        selectedArea == "Banani" && destination == "Motijheel" -> 7.8
        selectedArea == "Dhanmondi" && destination == "Motijheel" -> 4.5
        selectedArea == "Dhanmondi" && destination == "Gulshan" -> 6.8
        selectedArea == "Bashundhara" && destination == "Motijheel" -> 11.0
        selectedArea == "Bashundhara" && destination == "Gulshan" -> 4.0
        else -> 7.2
    }

    val speedKmh = when (transportMode) {
        "Metro Rail" -> 45.0 // Swift bypass traffic
        "Car / Uber" -> 12.0 // Slow city traffic jam
        "CNG Auto" -> 15.0  // Can squeeze through
        "Rickshaw" -> 8.0   // Traditional short distance
        "Walking" -> 4.5    // Safe pathways
        else -> 10.0
    }

    val trafficDelayMins = when (transportMode) {
        "Metro Rail" -> 2.0 // Zero traffic delays
        "Car / Uber" -> 35.0 // Serious Gulshan/Banani jam
        "CNG Auto" -> 20.0
        "Rickshaw" -> 10.0
        "Walking" -> 0.0
        else -> 15.0
    }

    val travelTimeMins = ((distanceKm / speedKmh) * 60.0 + trafficDelayMins).roundToInt()
    val costEstimate = when (transportMode) {
        "Metro Rail" -> (distanceKm * 5 + 20).roundToInt().coerceIn(20, 100)
        "Car / Uber" -> (distanceKm * 40 + 150).roundToInt().coerceIn(150, 800)
        "CNG Auto" -> (distanceKm * 25 + 100).roundToInt().coerceIn(120, 400)
        "Rickshaw" -> (distanceKm * 35 + 40).roundToInt().coerceIn(40, 200)
        "Walking" -> 0
        else -> 50
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- AREA CHIPS ---
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Select Neighborhood Guide:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                neighborhoods.forEach { area ->
                    val isSel = selectedArea == area
                    FilterChip(
                        selected = isSel,
                        onClick = { selectedArea = area },
                        label = { Text(area, fontWeight = FontWeight.Bold) }
                    )
                }
            }
        }

        // --- SECTION 1: AREA HERO SUMMARY ---
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("$selectedArea Guide", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE8F5E9))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Live Trends", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32))
                    }
                }

                Text(
                    text = "A premier neighborhood of Dhaka known for its unique blend of security, standard communication, and top commercial infrastructure.",
                    fontSize = 11.sp,
                    color = Color.DarkGray,
                    lineHeight = 14.sp
                )

                Divider(color = Color.LightGray.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Average Rent (2026)", fontSize = 10.sp, color = Color.Gray)
                        Text("৳${rentTrends.last().toString().reversed().chunked(3).joinToString(",").reversed()}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Security Index", fontSize = 10.sp, color = Color.Gray)
                        Text(securityGrade.split(" ")[1], fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32))
                    }
                }
            }
        }

        // --- SECTION 2: GRAPHICAL RENT TREND CHART ---
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.ShowChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Text("Rental Price YoY Inflation Trend (2022-2026)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Divider(color = Color.LightGray.copy(alpha = 0.3f))

                // Draw standard vertical bar chart using Row + weight
                val years = listOf("2022", "2023", "2024", "2025", "2026")
                val maxRent = rentTrends.maxOrNull() ?: 100000

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .padding(top = 10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.Bottom
                ) {
                    rentTrends.forEachIndexed { idx, rent ->
                        val pct = rent.toFloat() / maxRent.toFloat()
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Bottom,
                            modifier = Modifier.fillMaxHeight().weight(1f)
                        ) {
                            Text("৳${rent / 1000}k", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.5f)
                                    .fillMaxHeight(pct * 0.8f) // Scale appropriately
                                    .clip(RoundedCornerShape(t_left = 4.dp, t_right = 4.dp, b_left = 0.dp, b_right = 0.dp))
                                    .background(
                                        if (idx == 4) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f)
                                    )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(years[idx], fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                // Growth rate calculator text callout
                val diffPct = ((rentTrends.last() - rentTrends.first()).toDouble() / rentTrends.first().toDouble()) * 100.0
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f), RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (diffPct > 0) "📈 Rental prices have grown by ${String.format("%.1f", diffPct)}% over the last 5 years in $selectedArea."
                        else "📉 Average rents stabilized with -1.7% adjustment due to decentralization.",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // --- SECTION 3: KEY INFRASTRUCTURE AMENITIES ---
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("📍 Local Infrastructure & Perks", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Divider(color = Color.LightGray.copy(alpha = 0.3f))

                // Schools
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Column {
                        Text("Top Schools & Universities", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        schoolList.forEach { s ->
                            Text("• $s", fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Hospitals
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Filled.LocalHospital, contentDescription = null, tint = Color.Red, modifier = Modifier.size(18.dp))
                    Column {
                        Text("Healthcare & Hospitals", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        hospitalList.forEach { h ->
                            Text("• $h", fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Transport
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Filled.DirectionsTransit, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(18.dp))
                    Column {
                        Text("Transit & Transport Links", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        transportList.forEach { t ->
                            Text("• $t", fontSize = 11.sp, color = Color.DarkGray)
                        }
                    }
                }
            }
        }

        // --- SECTION 4: COMMUTE-TIME ESTIMATOR ---
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.DepartureBoard, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
                    Text("Commute-Time Estimator & Route Cost", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Text(
                    "Select a standard destination in Dhaka and your preferred mode of transport to estimate transit delays and route fare prices.",
                    fontSize = 11.sp,
                    color = Color.DarkGray,
                    lineHeight = 14.sp
                )

                Divider(color = Color.LightGray.copy(alpha = 0.2f))

                // Select Destination
                Text("Select Key Target Area:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Gulshan", "Motijheel", "Uttara").forEach { dest ->
                        val isSel = destination == dest
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) MaterialTheme.colorScheme.secondary else Color.LightGray.copy(alpha = 0.2f))
                                .clickable { destination = dest }
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(dest, fontSize = 11.sp, color = if (isSel) Color.White else Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Select Mode of Transport
                Text("Select Transport Mode:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Metro Rail", "Car / Uber", "CNG Auto", "Rickshaw", "Walking").forEach { mode ->
                        val isSel = transportMode == mode
                        FilterChip(
                            selected = isSel,
                            onClick = { transportMode = mode },
                            label = { Text(mode, fontSize = 10.sp) }
                        )
                    }
                }

                // Estimator Output Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Route: $selectedArea ➔ $destination", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Distance: ${String.format("%.1f", distanceKm)} km", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        }

                        Divider(color = Color.LightGray.copy(alpha = 0.2f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = if (transportMode == "Metro Rail") Icons.Filled.DirectionsSubway else Icons.Filled.DirectionsCar,
                                    contentDescription = null,
                                    tint = if (transportMode == "Metro Rail") Color(0xFF2E7D32) else Color.DarkGray,
                                    modifier = Modifier.size(22.dp)
                                )
                                Column {
                                    Text("Estimated Duration", fontSize = 10.sp, color = Color.Gray)
                                    Text("$travelTimeMins minutes", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Estimated Cost", fontSize = 10.sp, color = Color.Gray)
                                Text(if (costEstimate == 0) "Free" else "৳$costEstimate BDT", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        // Traffic mitigation tip
                        if (transportMode == "Metro Rail") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFE8F5E9), RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Text("🌿 Metro bypass active: Slashes traffic jams and saves up to 45 mins on peak office slots!", fontSize = 9.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                            }
                        } else if (travelTimeMins > 45) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFFFEBEE), RoundedCornerShape(4.dp))
                                    .padding(6.dp)
                            ) {
                                Text("⚠️ High Traffic Jam on Satmasjid/Kakoli Corridors! Searing delays expected. Switch to Metro Rail to cut route lag.", fontSize = 9.sp, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Helper Rounded Corner Shape Clip extensions to avoid compiling errors
private fun RoundedCornerShape(
    t_left: androidx.compose.ui.unit.Dp,
    t_right: androidx.compose.ui.unit.Dp,
    b_left: androidx.compose.ui.unit.Dp,
    b_right: androidx.compose.ui.unit.Dp
): RoundedCornerShape {
    return RoundedCornerShape(
        topStart = t_left,
        topEnd = t_right,
        bottomStart = b_left,
        bottomEnd = b_right
    )
}
