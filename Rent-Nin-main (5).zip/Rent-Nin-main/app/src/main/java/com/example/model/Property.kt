package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "properties")
data class Property(
    @PrimaryKey val id: String,
    val title: String,
    val slug: String,
    val description: String,
    val listingType: String, // "rent"
    val price: Double,
    val currency: String = "৳",
    val bedrooms: Int,
    val bathrooms: Int,
    val areaSqft: Int,
    val address: String,
    val city: String,
    val featured: Boolean = false,
    val verified: Boolean = false,
    val audience: String = "", // "family", "corporate", or empty
    val imageUrl: String = "",
    val additionalImages: String = "", // comma separated urls/placeholders
    val furnished: Boolean = false,
    val propertyType: String = "Apartment", // "Apartment", "Office", "Retail", "Sublet"
    val neighborhood: String = "Gulshan", // "Gulshan", "Banani", "Dhanmondi", "Uttara", "Bashundhara", "Mirpur"
    val availabilityDate: String = "Available Now",
    val latitude: Double = 23.7937,
    val longitude: Double = 90.4066,
    val ownerName: String = "Premium Owner",
    val ownerPhone: String = "+8801700000000",
    val ownerRating: Double = 4.8,
    val ownerResponseTime: String = "Within 1 hour",
    val isRented: Boolean = false,
    val viewsCount: Int = 100,
    val timestamp: Long = System.currentTimeMillis(),
    val isExpired: Boolean = false,
    val floorNumber: Int = 1,
    val isDraft: Boolean = false,
    val isApproved: Boolean = true, // For admin review queue (pending vs approved)
    val promoType: String = "Free", // "Free", "Featured", "Urgent"
    val sellerType: String = "Individual", // "Individual", "Agent"
    val subCategory: String = "Family", // e.g. Apartments -> "Family" / "Bachelor" / "Sublet"
    val callsCount: Int = 0,
    val whatsappClicksCount: Int = 0,
    val favoritesCount: Int = 0
)

@Entity(tableName = "favorites")
data class FavoriteProperty(
    @PrimaryKey val propertyId: String
)

@Entity(tableName = "inquiries")
data class Inquiry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val details: String,
    val propertyTitle: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String // "Renter", "Corporate", "Landlord", "Contact"
)

@Entity(tableName = "search_history")
data class SearchHistory(
    @PrimaryKey val query: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_searches")
data class SavedSearch(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val query: String,
    val category: String = "All",
    val minPrice: Double = 0.0,
    val maxPrice: Double = 150000.0,
    val bedrooms: Int = 0,
    val bathrooms: Int = 0,
    val furnished: Boolean? = null,
    val propertyType: String = "All",
    val neighborhood: String = "All",
    val notifyMe: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val propertyId: String,
    val propertyTitle: String,
    val senderName: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFromUser: Boolean = true
)
