package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DeepNavy = Color(0xFF0C2340)
val AccentGreen = Color(0xFF00A651)
val AccentSoft = Color(0xFFE6F6EE)
val LightBg = Color(0xFFF8FAFC)
val CardBg = Color(0xFFFFFFFF)
val MutedText = Color(0xFF64748B)
val BorderColor = Color(0xFFE2E8F0)

private val LightColorScheme = lightColorScheme(
    primary = DeepNavy,
    onPrimary = Color.White,
    secondary = AccentGreen,
    onSecondary = Color.White,
    tertiary = AccentSoft,
    background = LightBg,
    surface = CardBg,
    onBackground = DeepNavy,
    onSurface = DeepNavy,
    outline = BorderColor
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF1E3A8A),
    onPrimary = Color.White,
    secondary = AccentGreen,
    onSecondary = Color.White,
    background = Color(0xFF0F172A),
    surface = Color(0xFF1E293B),
    onBackground = Color.White,
    onSurface = Color.White,
    outline = Color(0xFF334155)
)

@Composable
fun RentNinTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
