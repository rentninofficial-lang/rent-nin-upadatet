package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Property
import com.example.ui.RentViewModel
import kotlinx.coroutines.launch

@Composable
fun AdminDashboardView(
    viewModel: RentViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    val properties by viewModel.allProperties.collectAsState(initial = emptyList())
    val inquiries by viewModel.inquiries.collectAsState(initial = emptyList())
    
    val abTestEnabled by viewModel.abTestEnabled.collectAsState()
    val activeCardLayout by viewModel.activeCardLayout.collectAsState()
    val layoutAViews by viewModel.layoutAViews.collectAsState()
    val layoutAClicks by viewModel.layoutAClicks.collectAsState()
    val layoutBViews by viewModel.layoutBViews.collectAsState()
    val layoutBClicks by viewModel.layoutBClicks.collectAsState()

    // Derived statistics
    val totalListings = properties.size
    val pendingListings = properties.filter { !it.isApproved && !it.isDraft }
    
    val totalViews = properties.sumOf { it.viewsCount } + layoutAViews + layoutBViews
    val totalLeadClicks = properties.sumOf { it.callsCount + it.whatsappClicksCount } + layoutAClicks + layoutBClicks
    val totalInquiries = inquiries.size
    val totalContacts = totalLeadClicks + totalInquiries

    val conversionRate = if (totalViews > 0) {
        (totalContacts.toDouble() / totalViews.toDouble() * 100.0)
    } else {
        0.0
    }

    // Top areas calculation
    val areaViews = properties.groupBy { it.neighborhood }
        .mapValues { entry -> entry.value.sumOf { it.viewsCount } }
        .toList()
        .sortedByDescending { it.second }
        .take(3)

    // Fraud detection queue simulation
    var flaggedListings by remember(properties) {
        mutableStateOf(
            properties.filter { p ->
                // Flag listings with suspicious criteria
                val isSuspiciousPrice = (p.price < 5000 && p.neighborhood.lowercase() in listOf("gulshan", "banani", "dhanmondi"))
                val isShortDescription = p.description.length < 35
                val isSpamKeywords = p.title.lowercase().contains("free") || p.title.lowercase().contains("lottery") || p.title.lowercase().contains("win")
                isSuspiciousPrice || isShortDescription || isSpamKeywords || !p.isApproved
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- SECTION 1: HEADER SUMMARY ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AdminPanelSettings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(32.dp)
                    )
                    Column {
                        Text(
                            "Rentnin Admin Control Room",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "Real-time fraud screening, conversion funnel, and layout A/B test experiments.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // --- SECTION 2: SYSTEM COUNTERS ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("TOTAL LISTINGS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("$totalListings", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        Text("Active on search", fontSize = 9.sp, color = Color.Gray)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("PENDING REVIEW", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("${pendingListings.size}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFE65100))
                        Text("Requires moderation", fontSize = 9.sp, color = Color.Gray)
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ACTIVE USERS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Text("46", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32))
                        Text("Live sessions", fontSize = 9.sp, color = Color.Gray)
                    }
                }
            }
        }

        // --- SECTION 3: CONVERSION FUNNEL ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Filled.Leaderboard, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text("Performance Conversion Funnel (Views → Contacts)", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                    }

                    Divider(color = Color.LightGray.copy(alpha = 0.3f))

                    // Funnel Step 1: Catalog views
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("👁️ Total Catalog views", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("$totalViews", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        LinearProgressIndicator(
                            progress = 1.0f,
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = Color.LightGray.copy(alpha = 0.3f),
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        )
                    }

                    // Funnel Step 2: Clicks / Actions
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val pct = if (totalViews > 0) totalLeadClicks.toFloat() / totalViews.toFloat() else 0.0f
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("📞 Direct lead clicks (Call/WhatsApp)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("$totalLeadClicks (${String.format("%.1f", pct * 100)}%)", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        LinearProgressIndicator(
                            progress = pct,
                            color = MaterialTheme.colorScheme.secondary,
                            trackColor = Color.LightGray.copy(alpha = 0.3f),
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        )
                    }

                    // Funnel Step 3: Enquiries Submitted
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        val pct = if (totalViews > 0) totalInquiries.toFloat() / totalViews.toFloat() else 0.0f
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("✉️ Formal enquiries submitted", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("$totalInquiries (${String.format("%.1f", pct * 100)}%)", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        LinearProgressIndicator(
                            progress = pct,
                            color = Color(0xFFE65100),
                            trackColor = Color.LightGray.copy(alpha = 0.3f),
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        )
                    }

                    // Final conversion card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Overall Platform Conversion Rate:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                            Text("${String.format("%.2f", conversionRate)}%", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32))
                        }
                    }

                    // Top-performing areas
                    Text("📍 Top-Performing Neighborhoods (by views):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        areaViews.forEachIndexed { idx, (area, views) ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("#${idx + 1} $area", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                    Text("$views views", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        if (areaViews.isEmpty()) {
                            Text("No views recorded yet.", fontSize = 10.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }

        // --- SECTION 4: A/B TESTING PANEL ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Filled.Science, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Text("Listing Card A/B Testing Panel", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                        }
                        Switch(
                            checked = abTestEnabled,
                            onCheckedChange = { viewModel.abTestEnabled.value = it }
                        )
                    }

                    Text(
                        "Configure live layout experiments. When active, Rentnin randomly maps listings to Layout A (Classic) or Layout B (Contemporary Premium) in a deterministic split and tracks conversion.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        lineHeight = 14.sp
                    )

                    Divider(color = Color.LightGray.copy(alpha = 0.3f))

                    if (!abTestEnabled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Selected Fixed Layout:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = activeCardLayout == "Classic",
                                    onClick = { viewModel.activeCardLayout.value = "Classic" },
                                    label = { Text("Layout A (Classic)", fontSize = 10.sp) }
                                )
                                FilterChip(
                                    selected = activeCardLayout == "Contemporary Premium",
                                    onClick = { viewModel.activeCardLayout.value = "Contemporary Premium" },
                                    label = { Text("Layout B (Premium)", fontSize = 10.sp) }
                                )
                            }
                        }
                    }

                    // A/B real-time statistics comparison
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Layout A stats
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Layout A (Classic)", fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, color = Color.Gray)
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Views:", fontSize = 10.sp, color = Color.Gray)
                                    Text("$layoutAViews", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Clicks:", fontSize = 10.sp, color = Color.Gray)
                                    Text("$layoutAClicks", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                val ctr = if (layoutAViews > 0) (layoutAClicks.toDouble() / layoutAViews.toDouble() * 100.0) else 0.0
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("CTR:", fontSize = 10.sp, color = Color.Gray)
                                    Text("${String.format("%.1f", ctr)}%", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }

                        // Layout B stats
                        val ctrB = if (layoutBViews > 0) (layoutBClicks.toDouble() / layoutBViews.toDouble() * 100.0) else 0.0
                        val ctrA = if (layoutAViews > 0) (layoutAClicks.toDouble() / layoutAViews.toDouble() * 100.0) else 0.0
                        val isWinnerB = ctrB > ctrA
                        
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isWinnerB && layoutBViews > 0) Color(0xFFE8F5E9) else Color(0xFFFAFAFA)
                            ),
                            border = BorderStroke(
                                width = if (isWinnerB && layoutBViews > 0) 1.5.dp else 1.dp,
                                color = if (isWinnerB && layoutBViews > 0) Color(0xFF388E3C) else Color.LightGray.copy(alpha = 0.3f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Layout B (Premium)", fontWeight = FontWeight.ExtraBold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                    if (isWinnerB && layoutBViews > 0) {
                                        Text("🏆 WINNING", fontSize = 8.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32))
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Views:", fontSize = 10.sp, color = Color.Gray)
                                    Text("$layoutBViews", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("Clicks:", fontSize = 10.sp, color = Color.Gray)
                                    Text("$layoutBClicks", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("CTR:", fontSize = 10.sp, color = Color.Gray)
                                    Text("${String.format("%.1f", ctrB)}%", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32))
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { 
                                viewModel.resetAbTestStats()
                                Toast.makeText(context, "Statistics reset successfully!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset Experiment Data", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // --- SECTION 5: FRAUD & SPAM PATTERN DETECTION ALERTS ---
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Filled.ReportProblem, contentDescription = null, tint = Color(0xFFD32F2F), modifier = Modifier.size(18.dp))
                Text("AI Fraud & Spam Vetting Queue (${flaggedListings.size} Alerts)", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
        }

        if (flaggedListings.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Color(0xFF388E3C))
                        Text("No suspicious listing or fraud alerts detected on the network. All verified active catalog nodes are compliant.", fontSize = 11.sp, color = Color(0xFF2E7D32))
                    }
                }
            }
        } else {
            items(flaggedListings) { property ->
                // Custom Fraud Detail Alert Card
                val isSuspiciousPrice = (property.price < 5000 && property.neighborhood.lowercase() in listOf("gulshan", "banani", "dhanmondi"))
                val isShortDescription = property.description.length < 35
                val isSpamKeywords = property.title.lowercase().contains("free") || property.title.lowercase().contains("lottery") || property.title.lowercase().contains("win")
                
                val alertReason = when {
                    isSuspiciousPrice -> "⚠️ Rent Anomaly: Price ৳${property.price.toInt()} is extremely low for the prestigious ${property.neighborhood} neighborhood. High probability of advance payment scammer."
                    isSpamKeywords -> "⚠️ Spam keywords: Title contains high-probability advertisement or bait strings."
                    isShortDescription -> "⚠️ Insufficient spec logs: Description is extremely short (${property.description.length} chars) or lacks structural metadata."
                    !property.isApproved -> "⚠️ Review Queue: Landlord has submitted this new listing. Awaiting admin approval."
                    else -> "⚠️ General quality audit flagged."
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.2.dp, if (isSuspiciousPrice || isSpamKeywords) Color(0xFFD32F2F) else Color(0xFFFFB300)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = property.imageUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(50.dp).clip(RoundedCornerShape(6.dp))
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(property.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("By: ${property.ownerName} (${property.ownerPhone})", fontSize = 10.sp, color = Color.Gray)
                                Text("Rent: ৳${property.price.toInt()} · Address: ${property.address}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSuspiciousPrice || isSpamKeywords) Color(0xFFFFEBEE) else Color(0xFFFFF8E1))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isSuspiciousPrice || isSpamKeywords) "CRITICAL" else "WARNING",
                                    color = if (isSuspiciousPrice || isSpamKeywords) Color(0xFFC62828) else Color(0xFFF57F17),
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSuspiciousPrice || isSpamKeywords) Color(0xFFFFEBEE) else Color(0xFFFFF8E1)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = alertReason,
                                fontSize = 10.sp,
                                color = if (isSuspiciousPrice || isSpamKeywords) Color(0xFFC62828) else Color(0xFFF57F17),
                                modifier = Modifier.padding(8.dp),
                                lineHeight = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Moderation buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        viewModel.deleteProperty(property.id)
                                        Toast.makeText(context, "🚫 Listing banned and deleted!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, Color(0xFFD32F2F)),
                                modifier = Modifier.height(30.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Delete / Ban", color = Color(0xFFD32F2F), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                            
                            Spacer(modifier = Modifier.width(6.dp))

                            Button(
                                onClick = {
                                    scope.launch {
                                        viewModel.approveListing(property.id)
                                        Toast.makeText(context, "✅ Listing approved and cleared!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(30.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Approve & Clear", fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
