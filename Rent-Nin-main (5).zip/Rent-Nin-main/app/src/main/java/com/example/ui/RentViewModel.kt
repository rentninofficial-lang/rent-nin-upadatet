package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.RentRepository
import com.example.model.Inquiry
import com.example.model.Property
import com.example.model.SearchHistory
import com.example.model.SavedSearch
import com.example.model.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RentViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "rentnin_db"
    ).fallbackToDestructiveMigration()
     .build()

    private val repository = RentRepository(db)

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    // Filter states
    val searchQuery = MutableStateFlow("")
    val selectedCity = MutableStateFlow("All") // "All", "Dhaka"
    val selectedCategory = MutableStateFlow("All") // "All", "Apartment", "Office", etc.
    val selectedAudience = MutableStateFlow("All") // "All", "family", "corporate"
    val minPrice = MutableStateFlow(0.0)
    val maxPrice = MutableStateFlow(200000.0)
    val minBedrooms = MutableStateFlow(0)
    val minBathrooms = MutableStateFlow(0)
    val selectedFurnished = MutableStateFlow<Boolean?>(null) // null = Any, true = Furnished, false = Unfurnished
    val selectedNeighborhood = MutableStateFlow("All") // "All", "Gulshan", "Banani", etc.
    val sortBy = MutableStateFlow("Newest") // "Newest", "Price: Low to High", "Price: High to Low", "Most Viewed"
    val selectedListingType = MutableStateFlow("For Rent")
    val selectedSubCategory = MutableStateFlow("All") // "All", "Family", "Bachelor", "Female-only", "Sublet"

    // Cookie Consent Compliance State
    val cookieConsentAccepted = MutableStateFlow(false)

    // Compare Listings State
    val selectedCompareIds = MutableStateFlow<Set<String>>(emptySet())

    fun toggleCompare(propertyId: String): Boolean {
        val current = selectedCompareIds.value
        if (current.contains(propertyId)) {
            selectedCompareIds.value = current - propertyId
            return false
        } else {
            if (current.size >= 3) {
                return false
            }
            selectedCompareIds.value = current + propertyId
            return true
        }
    }

    fun clearCompare() {
        selectedCompareIds.value = emptySet()
    }

    // A/B Testing States & Performance Tracking
    val abTestEnabled = MutableStateFlow(true)
    val activeCardLayout = MutableStateFlow("Contemporary Premium") // "Classic" or "Contemporary Premium"
    val layoutAViews = MutableStateFlow(125)
    val layoutAClicks = MutableStateFlow(12)
    val layoutBViews = MutableStateFlow(138)
    val layoutBClicks = MutableStateFlow(23)

    fun getLayoutForProperty(id: String): String {
        return if (abTestEnabled.value) {
            if (id.hashCode() % 2 == 0) "Classic" else "Contemporary Premium"
        } else {
            activeCardLayout.value
        }
    }

    fun recordCardView(layout: String) {
        if (layout == "Classic") {
            layoutAViews.value += 1
        } else {
            layoutBViews.value += 1
        }
    }

    fun recordCardClick(layout: String) {
        if (layout == "Classic") {
            layoutAClicks.value += 1
        } else {
            layoutBClicks.value += 1
        }
    }

    fun resetAbTestStats() {
        layoutAViews.value = 0
        layoutAClicks.value = 0
        layoutBViews.value = 0
        layoutBClicks.value = 0
    }

    // Raw database state
    val allProperties = repository.allProperties
    val favorites = repository.allFavorites
    val inquiries = repository.allInquiries
    val recentSearches = repository.recentSearches
    val savedSearches = repository.savedSearches

    fun saveSearch(query: String) {
        viewModelScope.launch {
            repository.saveSearchQuery(query)
        }
    }

    fun deleteSearch(query: String) {
        viewModelScope.launch {
            repository.deleteSearchQuery(query)
        }
    }

    fun clearSearchHistory() {
        viewModelScope.launch {
            repository.clearSearchHistory()
        }
    }

    // Saved Search Alerts
    fun addSavedSearchAlert(
        query: String,
        category: String,
        minP: Double,
        maxP: Double,
        beds: Int,
        baths: Int,
        furnished: Boolean?,
        neighborhood: String
    ) {
        viewModelScope.launch {
            repository.addSavedSearch(
                SavedSearch(
                    query = query,
                    category = category,
                    minPrice = minP,
                    maxPrice = maxP,
                    bedrooms = beds,
                    bathrooms = baths,
                    furnished = furnished,
                    neighborhood = neighborhood,
                    notifyMe = true
                )
            )
        }
    }

    fun deleteSavedSearchAlert(id: Int) {
        viewModelScope.launch {
            repository.deleteSavedSearch(id)
        }
    }

    // Chat operations
    fun getChatMessages(propertyId: String): Flow<List<ChatMessage>> {
        return repository.getChatMessages(propertyId)
    }

    fun sendChatMessage(propertyId: String, propertyTitle: String, senderName: String, text: String, isFromUser: Boolean = true) {
        viewModelScope.launch {
            repository.sendChatMessage(
                ChatMessage(
                    propertyId = propertyId,
                    propertyTitle = propertyTitle,
                    senderName = senderName,
                    messageText = text,
                    isFromUser = isFromUser
                )
            )
        }
    }

    // Increment view count when viewing property details
    fun incrementPropertyViews(id: String) {
        viewModelScope.launch {
            repository.incrementViews(id)
            recordCardView(getLayoutForProperty(id))
        }
    }

    // Toggle property rented status
    fun toggleRentedStatus(id: String, currentRented: Boolean) {
        viewModelScope.launch {
            repository.updateRentedStatus(id, !currentRented)
        }
    }

    // Add property (for Owners Dashboard bulk upload / addition)
    fun addNewProperty(property: Property) {
        viewModelScope.launch {
            repository.addProperty(property)
        }
    }

    // Delete property
    fun deleteProperty(id: String) {
        viewModelScope.launch {
            repository.deleteProperty(id)
        }
    }

    fun incrementCallsCount(id: String) {
        viewModelScope.launch {
            repository.incrementCalls(id)
            recordCardClick(getLayoutForProperty(id))
        }
    }

    fun incrementWhatsappClicksCount(id: String) {
        viewModelScope.launch {
            repository.incrementWhatsappClicks(id)
            recordCardClick(getLayoutForProperty(id))
        }
    }

    fun approveListing(id: String) {
        viewModelScope.launch {
            repository.updateApprovalStatus(id, true)
        }
    }

    fun rejectListing(id: String) {
        viewModelScope.launch {
            repository.updateApprovalStatus(id, false)
        }
    }

    fun renewListing(id: String) {
        viewModelScope.launch {
            repository.updateTimestamp(id, System.currentTimeMillis())
        }
    }

    // Filtered property flows
    val filteredProperties: StateFlow<List<Property>> = combine(
        allProperties,
        searchQuery,
        selectedCity,
        selectedCategory,
        selectedAudience,
        minPrice,
        maxPrice,
        minBedrooms,
        minBathrooms,
        selectedFurnished,
        selectedNeighborhood,
        sortBy,
        selectedListingType,
        selectedSubCategory
    ) { flows: Array<Any?> ->
        val properties = flows[0] as List<Property>
        val query = flows[1] as String
        val city = flows[2] as String
        val category = flows[3] as String
        val audience = flows[4] as String
        val minP = flows[5] as Double
        val maxP = flows[6] as Double
        val beds = flows[7] as Int
        val baths = flows[8] as Int
        val furnished = flows[9] as Boolean?
        val neighborhood = flows[10] as String
        val sortCriteria = flows[11] as String
        val listingType = flows[12] as String
        val subCategory = flows[13] as String

        val filtered = properties.filter { p ->
            // Filter out drafts, pending approvals, or expired from public searches
            if (p.isDraft || !p.isApproved) return@filter false
            
            // Check expiration: 30 days limit
            val ageDays = (System.currentTimeMillis() - p.timestamp) / (1000 * 60 * 60 * 24)
            if (p.isExpired || ageDays >= 30) return@filter false

            val matchesQuery = query.isEmpty() || p.title.contains(query, ignoreCase = true) || p.description.contains(query, ignoreCase = true) || p.address.contains(query, ignoreCase = true)
            val matchesCity = city == "All" || p.city.equals(city, ignoreCase = true)
            
            // Handle Category exactly
            val matchesCategory = category == "All" || p.propertyType.equals(category, ignoreCase = true) || p.propertyType.contains(category, ignoreCase = true)
            
            val matchesAudience = audience == "All" || p.audience.equals(audience, ignoreCase = true)
            val matchesPrice = p.price in minP..maxP
            val matchesBeds = beds == 0 || p.bedrooms >= beds
            val matchesBaths = baths == 0 || p.bathrooms >= baths
            val matchesFurnished = furnished == null || p.furnished == furnished
            val matchesNeighborhood = neighborhood == "All" || p.neighborhood.equals(neighborhood, ignoreCase = true)
            
            // Match For Rent
            val matchesListingType = p.listingType.equals("rent", ignoreCase = true) || p.listingType.equals("For Rent", ignoreCase = true)

            // Match sub-filter category
            val matchesSubCategory = subCategory == "All" || p.subCategory.equals(subCategory, ignoreCase = true) || p.audience.equals(subCategory, ignoreCase = true)

            matchesQuery && matchesCity && matchesCategory && matchesAudience && matchesPrice && matchesBeds && matchesBaths && matchesFurnished && matchesNeighborhood && matchesListingType && matchesSubCategory
        }

        // Pin Featured and Urgent listings at the top of results
        val featuredListings = filtered.filter { it.featured || it.promoType == "Featured" || it.promoType == "Urgent" }
        val normalListings = filtered.filter { !it.featured && it.promoType != "Featured" && it.promoType != "Urgent" }

        fun sortGroup(list: List<Property>): List<Property> {
            return when (sortCriteria) {
                "Price: Low to High" -> list.sortedBy { p -> p.price }
                "Price: High to Low" -> list.sortedByDescending { p -> p.price }
                "Most Viewed" -> list.sortedByDescending { p -> p.viewsCount }
                "Newest" -> list.sortedByDescending { p -> p.timestamp }
                else -> list
            }
        }

        sortGroup(featuredListings) + sortGroup(normalListings)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun toggleFavorite(propertyId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(propertyId)
        }
    }

    fun isFavoriteFlow(propertyId: String): StateFlow<Boolean> {
        val flow = MutableStateFlow(false)
        viewModelScope.launch {
            repository.isFavoriteFlow(propertyId).collect {
                flow.value = it
            }
        }
        return flow
    }

    fun submitInquiry(name: String, phone: String, details: String, propertyTitle: String, type: String) {
        viewModelScope.launch {
            repository.submitInquiry(
                Inquiry(
                    name = name,
                    phone = phone,
                    details = details,
                    propertyTitle = propertyTitle,
                    type = type
                )
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        db.close()
    }
}
