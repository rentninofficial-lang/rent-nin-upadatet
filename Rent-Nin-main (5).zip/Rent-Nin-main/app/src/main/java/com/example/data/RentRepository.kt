package com.example.data

import com.example.model.FavoriteProperty
import com.example.model.Inquiry
import com.example.model.Property
import com.example.model.SearchHistory
import com.example.model.SavedSearch
import com.example.model.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class RentRepository(private val db: AppDatabase) {

    val allProperties: Flow<List<Property>> = db.propertyDao().getAllProperties()
    val allFavorites: Flow<List<FavoriteProperty>> = db.favoriteDao().getAllFavorites()
    val allInquiries: Flow<List<Inquiry>> = db.inquiryDao().getAllInquiries()
    val recentSearches: Flow<List<SearchHistory>> = db.searchHistoryDao().getRecentSearches()
    val savedSearches: Flow<List<SavedSearch>> = db.savedSearchDao().getAllSavedSearches()

    suspend fun saveSearchQuery(query: String) {
        if (query.isNotBlank()) {
            db.searchHistoryDao().insertSearch(SearchHistory(query = query.trim()))
        }
    }

    suspend fun deleteSearchQuery(query: String) {
        db.searchHistoryDao().deleteSearch(query)
    }

    suspend fun clearSearchHistory() {
        db.searchHistoryDao().clearAllSearchHistory()
    }

    // Saved searches
    suspend fun addSavedSearch(search: SavedSearch) {
        db.savedSearchDao().insertSavedSearch(search)
    }

    suspend fun deleteSavedSearch(id: Int) {
        db.savedSearchDao().deleteSavedSearch(id)
    }

    // In-app chat messages
    fun getChatMessages(propertyId: String): Flow<List<ChatMessage>> {
        return db.chatMessageDao().getChatMessages(propertyId)
    }

    suspend fun sendChatMessage(message: ChatMessage) {
        db.chatMessageDao().insertChatMessage(message)
    }

    suspend fun getPropertyBySlug(slug: String): Property? {
        return db.propertyDao().getPropertyBySlug(slug)
    }

    suspend fun getPropertyById(id: String): Property? {
        return db.propertyDao().getPropertyById(id)
    }

    suspend fun incrementViews(id: String) {
        db.propertyDao().incrementViews(id)
    }

    suspend fun incrementCalls(id: String) {
        db.propertyDao().incrementCalls(id)
    }

    suspend fun incrementWhatsappClicks(id: String) {
        db.propertyDao().incrementWhatsappClicks(id)
    }

    suspend fun updateApprovalStatus(id: String, approved: Boolean) {
        db.propertyDao().updateApprovalStatus(id, approved)
    }

    suspend fun updateTimestamp(id: String, timestamp: Long) {
        db.propertyDao().updateTimestamp(id, timestamp)
    }

    suspend fun updateRentedStatus(id: String, isRented: Boolean) {
        db.propertyDao().updateRentedStatus(id, isRented)
    }

    suspend fun deleteProperty(id: String) {
        db.propertyDao().deleteProperty(id)
    }

    suspend fun addProperty(property: Property) {
        db.propertyDao().insertProperties(listOf(property))
    }

    suspend fun toggleFavorite(propertyId: String) {
        if (db.favoriteDao().isFavorite(propertyId)) {
            db.favoriteDao().removeFavorite(propertyId)
        } else {
            db.favoriteDao().addFavorite(FavoriteProperty(propertyId))
        }
    }

    fun isFavoriteFlow(propertyId: String): Flow<Boolean> {
        return db.favoriteDao().isFavoriteFlow(propertyId)
    }

    suspend fun submitInquiry(inquiry: Inquiry) {
        db.inquiryDao().insertInquiry(inquiry)
    }

    suspend fun seedDatabaseIfEmpty() {
        val current = db.propertyDao().getAllProperties().first()
        if (current.isEmpty()) {
            val seed = listOf(
                Property(
                    id = "p1",
                    title = "Modern 3 Bed Luxury Flat",
                    slug = "modern-3-bed-luxury-flat-bashundhara",
                    description = "A spacious, newly built 3-bedroom apartment located in Block F of Bashundhara R/A. Features premium Italian marble fittings, large south-facing double-glazed balconies, 24/7 security, dual high-speed elevators, and reserved basement parking. Perfect for modern urban family living with nearby international schools and shopping malls.",
                    listingType = "rent",
                    price = 38000.0,
                    bedrooms = 3,
                    bathrooms = 3,
                    areaSqft = 1650,
                    address = "Block F, Bashundhara R/A",
                    city = "Dhaka",
                    featured = true,
                    verified = true,
                    audience = "family",
                    imageUrl = "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?w=600&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1613977257363-707ba9348227?w=600&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&auto=format&fit=crop&q=60",
                    furnished = true,
                    propertyType = "Apartment",
                    neighborhood = "Bashundhara",
                    availabilityDate = "Available Now",
                    latitude = 23.8193,
                    longitude = 90.4285,
                    ownerName = "Abrar Rahman",
                    ownerPhone = "+8801711223344",
                    ownerRating = 4.9,
                    ownerResponseTime = "Within 10 mins",
                    viewsCount = 425
                ),
                Property(
                    id = "p2",
                    title = "Premium Commercial Lakefront Office",
                    slug = "premium-office-space-gulshan-1",
                    description = "Executive commercial office space situated in the prime commercial heart of Gulshan 1. High floor with panoramic Banani Lake views, central air conditioning, fire safety systems, backup generator, high-speed elevators, and dedicated reception. Ideal for MNC corporate headquarters.",
                    listingType = "rent",
                    price = 145000.0,
                    bedrooms = 0,
                    bathrooms = 2,
                    areaSqft = 2400,
                    address = "Road 23, Gulshan 1",
                    city = "Dhaka",
                    featured = true,
                    verified = true,
                    audience = "corporate",
                    imageUrl = "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=600&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=600&auto=format&fit=crop&q=60",
                    furnished = false,
                    propertyType = "Office",
                    neighborhood = "Gulshan",
                    availabilityDate = "Aug 1, 2026",
                    latitude = 23.7801,
                    longitude = 90.4150,
                    ownerName = "Rezaul Karim",
                    ownerPhone = "+8801819283746",
                    ownerRating = 4.7,
                    ownerResponseTime = "Within 30 mins",
                    viewsCount = 890
                ),
                Property(
                    id = "p3",
                    title = "Ground Floor Commercial Showroom",
                    slug = "commercial-space-ground-floor-dhanmondi",
                    description = "Prime retail ground floor space with excellent road visibility and massive foot traffic on Dhanmondi Mirpur Road. Wide storefront display window, 14ft high ceilings, suitable for upscale restaurants, brand flagship showrooms, or consumer tech shops.",
                    listingType = "rent",
                    price = 85000.0,
                    bedrooms = 0,
                    bathrooms = 1,
                    areaSqft = 1200,
                    address = "Mirpur Road, Dhanmondi",
                    city = "Dhaka",
                    featured = false,
                    verified = true,
                    audience = "",
                    imageUrl = "https://images.unsplash.com/photo-1554469384-e58fac16e23a?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=800&auto=format&fit=crop&q=60",
                    furnished = false,
                    propertyType = "Retail",
                    neighborhood = "Dhanmondi",
                    availabilityDate = "Available Now",
                    latitude = 23.7461,
                    longitude = 90.3742,
                    ownerName = "Farhana Islam",
                    ownerPhone = "+8801911998877",
                    ownerRating = 4.5,
                    ownerResponseTime = "Within 1 hour",
                    viewsCount = 1012
                ),
                Property(
                    id = "p4",
                    title = "Elegantly Furnished 3 Bed Flat",
                    slug = "furnished-3-bed-apartment-banani",
                    description = "Fully interior-designed and elegantly furnished 3-bedroom luxury flat in Banani. Complete with custom Turkish furniture, smart IoT home appliances, fully equipped modular kitchen with dishwasher, smart geysers, ACs in all rooms, and a lovely maid quarter. Safe and prestigious location.",
                    listingType = "rent",
                    price = 75000.0,
                    bedrooms = 3,
                    bathrooms = 4,
                    areaSqft = 1850,
                    address = "Road 11, Banani",
                    city = "Dhaka",
                    featured = false,
                    verified = true,
                    audience = "family",
                    imageUrl = "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=600&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1617806118233-18e1db207f62?w=600&auto=format&fit=crop&q=60",
                    furnished = true,
                    propertyType = "Apartment",
                    neighborhood = "Banani",
                    availabilityDate = "Available Now",
                    latitude = 23.7937,
                    longitude = 90.4066,
                    ownerName = "Zahid Hasan",
                    ownerPhone = "+8801715566778",
                    ownerRating = 4.8,
                    ownerResponseTime = "Within 15 mins",
                    viewsCount = 672
                ),
                Property(
                    id = "p5",
                    title = "Premium Duplex Penthouse",
                    slug = "premium-duplex-penthouse-gulshan-2",
                    description = "A breathtaking 4-bedroom ultimate duplex penthouse overlooking the Gulshan Society Lake. Expansive living halls, custom architectural double-height ceilings, a private rooftop garden, complete modular kitchen set, biometric security lock, and servant quarters. Extremely secure VIP neighborhood.",
                    listingType = "rent",
                    price = 180000.0,
                    bedrooms = 4,
                    bathrooms = 5,
                    areaSqft = 3400,
                    address = "Madani Avenue, Gulshan 2",
                    city = "Dhaka",
                    featured = true,
                    verified = true,
                    audience = "family",
                    imageUrl = "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=600&auto=format&fit=crop&q=60",
                    furnished = true,
                    propertyType = "Apartment",
                    neighborhood = "Gulshan",
                    availabilityDate = "Available Now",
                    latitude = 23.7925,
                    longitude = 90.4162,
                    ownerName = "Tasnim Chowdhury",
                    ownerPhone = "+8801552345678",
                    ownerRating = 5.0,
                    ownerResponseTime = "Within 5 mins",
                    viewsCount = 1420
                ),
                Property(
                    id = "p6",
                    title = "Boutique Retail Shop in Arcade",
                    slug = "shop-space-prime-location-uttara",
                    description = "Highly visible corner commercial retail shop space in Uttara Sector 7. Located inside a highly popular community shopping arcade, ideal for clothing boutiques, electronics, cosmetics, or premium grooming salons. Wide glass facade for displays.",
                    listingType = "rent",
                    price = 45000.0,
                    bedrooms = 0,
                    bathrooms = 0,
                    areaSqft = 450,
                    address = "Sector 7, Uttara",
                    city = "Dhaka",
                    featured = false,
                    verified = false,
                    audience = "",
                    imageUrl = "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&auto=format&fit=crop&q=60",
                    furnished = false,
                    propertyType = "Retail",
                    neighborhood = "Uttara",
                    availabilityDate = "Available Now",
                    latitude = 23.8759,
                    longitude = 90.4007,
                    ownerName = "Mamunur Rashid",
                    ownerPhone = "+8801311223344",
                    ownerRating = 4.2,
                    ownerResponseTime = "Within 2 hours",
                    viewsCount = 310
                ),
                Property(
                    id = "p7",
                    title = "Cozy Family 2 Bed Flat",
                    slug = "cozy-2-bed-flat-mirpur-dohs",
                    description = "A warm, well-maintained, budget-friendly 2-bedroom home in the quiet, gated residential enclave of Mirpur DOHS. Features reliable 24/7 deep tubewell water, natural gas, full elevator, standby power generator backup, secure parking, and tree-lined streets. Extremely safe for children.",
                    listingType = "rent",
                    price = 26000.0,
                    bedrooms = 2,
                    bathrooms = 2,
                    areaSqft = 1150,
                    address = "Avenue 4, Mirpur DOHS",
                    city = "Dhaka",
                    featured = false,
                    verified = false,
                    audience = "family",
                    imageUrl = "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600&auto=format&fit=crop&q=60",
                    furnished = false,
                    propertyType = "Apartment",
                    neighborhood = "Mirpur",
                    availabilityDate = "Sept 1, 2026",
                    latitude = 23.8222,
                    longitude = 90.3657,
                    ownerName = "Major (Retd.) Wahid",
                    ownerPhone = "+8801711009988",
                    ownerRating = 4.6,
                    ownerResponseTime = "Within 45 mins",
                    viewsCount = 490
                ),
                Property(
                    id = "p8",
                    title = "Startup-Ready Shared Studio Office",
                    slug = "startup-ready-office-bashundhara",
                    description = "Ready-to-move-in, fully furnished plug-and-play coworking/studio layout in Bashundhara, ideal for tech startups and agency squads. Equipped with ergonomic chairs, high-capacity router infrastructure nodes, a modern shared media meeting room with smart projection, and unlimited tea/coffee lounge.",
                    listingType = "rent",
                    price = 58000.0,
                    bedrooms = 0,
                    bathrooms = 1,
                    areaSqft = 1100,
                    address = "Block C, Bashundhara R/A",
                    city = "Dhaka",
                    featured = false,
                    verified = true,
                    audience = "corporate",
                    imageUrl = "https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=600&auto=format&fit=crop&q=60",
                    additionalImages = "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&auto=format&fit=crop&q=60",
                    furnished = true,
                    propertyType = "Office",
                    neighborhood = "Bashundhara",
                    availabilityDate = "Available Now",
                    latitude = 23.8164,
                    longitude = 90.4244,
                    ownerName = "Sabbir Ahmed",
                    ownerPhone = "+8801611223344",
                    ownerRating = 4.7,
                    ownerResponseTime = "Within 15 mins",
                    viewsCount = 544
                )
            )
            db.propertyDao().insertProperties(seed)
        }
    }
}
