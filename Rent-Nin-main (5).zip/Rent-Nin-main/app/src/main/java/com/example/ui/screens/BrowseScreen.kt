package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Property
import com.example.model.SavedSearch
import com.example.ui.RentViewModel
import com.example.ui.components.PropertyCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    viewModel: RentViewModel,
    onPropertyClick: (Property) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val properties by viewModel.filteredProperties.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val minPrice by viewModel.minPrice.collectAsState()
    val maxPrice by viewModel.maxPrice.collectAsState()
    val minBedrooms by viewModel.minBedrooms.collectAsState()
    val minBathrooms by viewModel.minBathrooms.collectAsState()
    val selectedFurnished by viewModel.selectedFurnished.collectAsState()
    val selectedNeighborhood by viewModel.selectedNeighborhood.collectAsState()
    val sortBy by viewModel.sortBy.collectAsState()
    val selectedSubCategory by viewModel.selectedSubCategory.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }
    var isMapViewActive by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Search & Mode Toggles
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.value = it },
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp),
                placeholder = { Text("Search title, area...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = Color.Gray
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(
                                imageVector = Icons.Filled.Clear,
                                contentDescription = "Clear",
                                tint = Color.Gray
                            )
                        }
                    }
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(
                    onSearch = {
                        if (searchQuery.isNotBlank()) {
                            viewModel.saveSearch(searchQuery)
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color.LightGray,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                shape = RoundedCornerShape(26.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Map/List Mode Toggle Button
            IconButton(
                onClick = { isMapViewActive = !isMapViewActive },
                modifier = Modifier
                    .size(52.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
            ) {
                Icon(
                    imageVector = if (isMapViewActive) Icons.Filled.List else Icons.Filled.Map,
                    contentDescription = "Toggle View",
                    tint = Color.White
                )
            }
        }



        // 8 Categories Horizontal Quick Selector
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val categoryOptions = listOf(
                "All" to Icons.Filled.Dashboard,
                "Apartments/Flats" to Icons.Filled.Apartment,
                "Houses" to Icons.Filled.Home,
                "Land" to Icons.Filled.Landscape,
                "Commercial Space" to Icons.Filled.Store,
                "Office Space" to Icons.Filled.Business,
                "Shop/Restaurant Space" to Icons.Filled.Restaurant,
                "Hostel/Sublet" to Icons.Filled.Hotel,
                "Garage/Parking" to Icons.Filled.LocalParking
            )
            items(categoryOptions) { (cat, icon) ->
                val isSelected = (cat == "All" && selectedCategory == "All") || 
                                 (cat != "All" && selectedCategory == cat) ||
                                 (cat == "Apartments/Flats" && selectedCategory == "Apartment") ||
                                 (cat == "Office Space" && selectedCategory == "Office")
                
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        val valueToSet = when (cat) {
                            "Apartments/Flats" -> "Apartment"
                            "Office Space" -> "Office"
                            else -> cat
                        }
                        viewModel.selectedCategory.value = valueToSet
                        viewModel.selectedSubCategory.value = "All"
                    },
                    label = { Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    leadingIcon = {
                        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp))
                    }
                )
            }
        }

        // Category-Specific Sub-filters
        if (selectedCategory != "All") {
            val subFilters = when {
                selectedCategory.startsWith("Apartment") || selectedCategory.startsWith("House") || selectedCategory.startsWith("Hostel") -> {
                    listOf("All", "Family", "Bachelor", "Female-only", "Sublet")
                }
                selectedCategory.startsWith("Office") || selectedCategory.startsWith("Commercial") || selectedCategory.startsWith("Shop") -> {
                    listOf("All", "Corporate", "Coworking", "Private", "Shared")
                }
                else -> {
                    listOf("All", "Commercial", "Residential")
                }
            }
            
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp, start = 16.dp, end = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    Text("Sub-filters:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                }
                items(subFilters) { sf ->
                    val isSelected = selectedSubCategory == sf
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.secondary else Color.LightGray.copy(alpha = 0.2f))
                            .clickable { viewModel.selectedSubCategory.value = sf }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = sf,
                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Action controls (Filter, Sort, Save Search)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left actions: Filters + Save search
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { showFilterSheet = true },
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Filled.FilterList, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Filters", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Saved search alert trigger
                Button(
                    onClick = {
                        viewModel.addSavedSearchAlert(
                            query = searchQuery.ifBlank { "Any search" },
                            category = selectedCategory,
                            minP = minPrice,
                            maxP = maxPrice,
                            beds = minBedrooms,
                            baths = minBathrooms,
                            furnished = selectedFurnished,
                            neighborhood = selectedNeighborhood
                        )
                        Toast.makeText(context, "Search saved! Match alerts activated. 🔔", Toast.LENGTH_LONG).show()
                    },
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save & Alert", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Right action: Sorting
            Box {
                OutlinedButton(
                    onClick = { showSortMenu = true },
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(sortBy, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                }

                DropdownMenu(
                    expanded = showSortMenu,
                    onDismissRequest = { showSortMenu = false }
                ) {
                    listOf("Newest", "Price: Low to High", "Price: High to Low", "Most Viewed").forEach { criteria ->
                        DropdownMenuItem(
                            text = { Text(criteria, fontSize = 13.sp) },
                            onClick = {
                                viewModel.sortBy.value = criteria
                                showSortMenu = false
                            }
                        )
                    }
                }
            }
        }

        // Active Quick Filter Badges
        ActiveFilterBadgesView(viewModel = viewModel)

        // Main content screen (List or Custom Map)
        Box(modifier = Modifier.weight(1f)) {
            if (isMapViewActive) {
                DhakaMapView(properties = properties, onPropertyClick = onPropertyClick)
            } else {
                ListView(properties = properties, viewModel = viewModel, onPropertyClick = onPropertyClick)
            }
        }
    }

    // Advanced Filters Dialog
    if (showFilterSheet) {
        AlertDialog(
            onDismissRequest = { showFilterSheet = false },
            confirmButton = {
                Button(
                    onClick = { showFilterSheet = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Apply & Filter")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        viewModel.selectedCategory.value = "All"
                        viewModel.minPrice.value = 0.0
                        viewModel.maxPrice.value = 200000.0
                        viewModel.minBedrooms.value = 0
                        viewModel.minBathrooms.value = 0
                        viewModel.selectedFurnished.value = null
                        viewModel.selectedNeighborhood.value = "All"
                        showFilterSheet = false
                    }
                ) {
                    Text("Reset All", color = Color.Gray)
                }
            },
            title = {
                Text("Advanced Filters", fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Neighborhood Area Select
                    Column {
                        Text("Area / Neighborhood", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        val areas = listOf("All", "Gulshan", "Banani", "Dhanmondi", "Uttara", "Bashundhara", "Mirpur")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(areas) { area ->
                                val isSel = selectedNeighborhood == area
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f))
                                        .clickable { viewModel.selectedNeighborhood.value = area }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(area, color = if (isSel) Color.White else Color.Black, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    // Price Range Slider
                    Column {
                        Text(
                            "Rent Price Range: ৳${minPrice.toInt()} - ৳${maxPrice.toInt()}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        RangeSlider(
                            value = minPrice.toFloat()..maxPrice.toFloat(),
                            onValueChange = { range ->
                                viewModel.minPrice.value = range.start.toDouble()
                                viewModel.maxPrice.value = range.endInclusive.toDouble()
                            },
                            valueRange = 0f..200000f,
                            steps = 19,
                            colors = SliderDefaults.colors(
                                thumbColor = MaterialTheme.colorScheme.secondary,
                                activeTrackColor = MaterialTheme.colorScheme.secondary
                            )
                        )
                    }

                    // Property type selection
                    Column {
                        Text("Property Type", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        val types = listOf("All", "Apartment", "Office", "Retail", "Sublet")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            types.forEach { t ->
                                val isSel = selectedCategory == t
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f))
                                        .clickable { viewModel.selectedCategory.value = t }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(t, color = if (isSel) Color.White else Color.Black, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }

                    // Bedrooms Count Selector
                    Column {
                        Text("Min Bedrooms", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0, 1, 2, 3, 4).forEach { b ->
                                val isSel = minBedrooms == b
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f))
                                        .clickable { viewModel.minBedrooms.value = b },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(if (b == 0) "Any" else b.toString(), color = if (isSel) Color.White else Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Bathrooms Count Selector
                    Column {
                        Text("Min Bathrooms", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0, 1, 2, 3, 4).forEach { b ->
                                val isSel = minBathrooms == b
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f))
                                        .clickable { viewModel.minBathrooms.value = b },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(if (b == 0) "Any" else b.toString(), color = if (isSel) Color.White else Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Furnished Status Switch
                    Column {
                        Text("Furnishing", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val states = listOf(null to "Any", true to "Furnished", false to "Unfurnished")
                            states.forEach { (state, label) ->
                                val isSel = selectedFurnished == state
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f))
                                        .clickable { viewModel.selectedFurnished.value = state }
                                        .padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Text(label, color = if (isSel) Color.White else Color.Black, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun ActiveFilterBadgesView(viewModel: RentViewModel) {
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val minPrice by viewModel.minPrice.collectAsState()
    val maxPrice by viewModel.maxPrice.collectAsState()
    val minBedrooms by viewModel.minBedrooms.collectAsState()
    val minBathrooms by viewModel.minBathrooms.collectAsState()
    val selectedFurnished by viewModel.selectedFurnished.collectAsState()
    val selectedNeighborhood by viewModel.selectedNeighborhood.collectAsState()

    val hasActiveFilters = selectedCategory != "All" ||
            minPrice > 0.0 ||
            maxPrice < 200000.0 ||
            minBedrooms > 0 ||
            minBathrooms > 0 ||
            selectedFurnished != null ||
            selectedNeighborhood != "All"

    if (hasActiveFilters) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            item {
                Text("Active:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            }

            if (selectedNeighborhood != "All") {
                item {
                    FilterBadge(text = selectedNeighborhood, onClear = { viewModel.selectedNeighborhood.value = "All" })
                }
            }

            if (selectedCategory != "All") {
                item {
                    FilterBadge(text = selectedCategory, onClear = { viewModel.selectedCategory.value = "All" })
                }
            }

            if (minPrice > 0.0 || maxPrice < 200000.0) {
                item {
                    FilterBadge(
                        text = "৳${minPrice.toInt() / 1000}k-৳${maxPrice.toInt() / 1000}k",
                        onClear = {
                            viewModel.minPrice.value = 0.0
                            viewModel.maxPrice.value = 200000.0
                        }
                    )
                }
            }

            if (minBedrooms > 0) {
                item {
                    FilterBadge(text = "$minBedrooms+ Beds", onClear = { viewModel.minBedrooms.value = 0 })
                }
            }

            if (minBathrooms > 0) {
                item {
                    FilterBadge(text = "$minBathrooms+ Baths", onClear = { viewModel.minBathrooms.value = 0 })
                }
            }

            if (selectedFurnished != null) {
                val label = if (selectedFurnished == true) "Furnished" else "Unfurnished"
                item {
                    FilterBadge(text = label, onClear = { viewModel.selectedFurnished.value = null })
                }
            }
        }
    }
}

@Composable
fun FilterBadge(text: String, onClear: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.secondary.copy(alpha = 0.12f),
        modifier = Modifier.height(24.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = text, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Clear filter",
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier
                    .size(12.dp)
                    .clickable { onClear() }
            )
        }
    }
}

@Composable
fun ListView(
    properties: List<Property>,
    viewModel: RentViewModel,
    onPropertyClick: (Property) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (properties.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 60.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Filled.SearchOff,
                        contentDescription = "Not Found",
                        tint = Color.Gray,
                        modifier = Modifier.size(60.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No properties match your current criteria",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Adjust your advanced filters or try a wider search scope.",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(properties) { p ->
                PropertyCard(p = p, viewModel = viewModel, onPropertyClick = onPropertyClick)
            }
        }
    }
}

// Custom High-Fidelity Schematic Dhaka Map View
@Composable
fun DhakaMapView(
    properties: List<Property>,
    onPropertyClick: (Property) -> Unit
) {
    var selectedMapArea by remember { mutableStateOf("All") }
    val areasOfDhaka = listOf("Uttara", "Mirpur", "Bashundhara", "Banani", "Gulshan", "Dhanmondi")

    // Filter properties for the selected map area
    val mapFilteredProperties = if (selectedMapArea == "All") properties else properties.filter { it.neighborhood.equals(selectedMapArea, ignoreCase = true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Map Canvas Description
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.Map, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column {
                    Text("Interactive Dhaka Region Schematic Map", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("Select a neighborhood circle to focus pins and view listings.", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }

        // Custom Schematic layout representing Dhaka North-South geography
        // Box with fixed height acting as Map Workspace
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.3f)
                .background(Color(0xFFECEFF1), RoundedCornerShape(16.dp))
                .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            // Dhaka grid system / landmarks
            Text(
                "DHAKA METROPOLITAN SCHEMATIC",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray.copy(alpha = 0.6f),
                modifier = Modifier.align(Alignment.BottomStart)
            )

            // UTTER NORTH: Uttara
            AreaMarker(
                name = "Uttara",
                count = properties.count { it.neighborhood.equals("Uttara", ignoreCase = true) },
                isSelected = selectedMapArea == "Uttara",
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = 10.dp),
                onClick = { selectedMapArea = if (selectedMapArea == "Uttara") "All" else "Uttara" }
            )

            // NORTH WEST: Mirpur
            AreaMarker(
                name = "Mirpur",
                count = properties.count { it.neighborhood.equals("Mirpur", ignoreCase = true) },
                isSelected = selectedMapArea == "Mirpur",
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = 20.dp, y = (-40).dp),
                onClick = { selectedMapArea = if (selectedMapArea == "Mirpur") "All" else "Mirpur" }
            )

            // CENTRAL EAST: Bashundhara
            AreaMarker(
                name = "Bashundhara",
                count = properties.count { it.neighborhood.equals("Bashundhara", ignoreCase = true) },
                isSelected = selectedMapArea == "Bashundhara",
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .offset(x = (-10).dp, y = (-20).dp),
                onClick = { selectedMapArea = if (selectedMapArea == "Bashundhara") "All" else "Bashundhara" }
            )

            // CENTRAL WEST: Banani
            AreaMarker(
                name = "Banani",
                count = properties.count { it.neighborhood.equals("Banani", ignoreCase = true) },
                isSelected = selectedMapArea == "Banani",
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(x = (-30).dp, y = 10.dp),
                onClick = { selectedMapArea = if (selectedMapArea == "Banani") "All" else "Banani" }
            )

            // CENTRAL: Gulshan
            AreaMarker(
                name = "Gulshan",
                count = properties.count { it.neighborhood.equals("Gulshan", ignoreCase = true) },
                isSelected = selectedMapArea == "Gulshan",
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(x = 40.dp, y = 15.dp),
                onClick = { selectedMapArea = if (selectedMapArea == "Gulshan") "All" else "Gulshan" }
            )

            // SOUTH WEST: Dhanmondi
            AreaMarker(
                name = "Dhanmondi",
                count = properties.count { it.neighborhood.equals("Dhanmondi", ignoreCase = true) },
                isSelected = selectedMapArea == "Dhanmondi",
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset(x = (-50).dp, y = (-20).dp),
                onClick = { selectedMapArea = if (selectedMapArea == "Dhanmondi") "All" else "Dhanmondi" }
            )
        }

        // Horizontal Carousel of Selected Area properties
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (selectedMapArea == "All") "All Map Listings (${mapFilteredProperties.size})" else "Listings in $selectedMapArea (${mapFilteredProperties.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                if (selectedMapArea != "All") {
                    Text(
                        text = "Show All Areas",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.clickable { selectedMapArea = "All" }
                    )
                }
            }

            if (mapFilteredProperties.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No listings match active filter settings in this region.", color = Color.Gray, fontSize = 12.sp)
                }
            } else {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(mapFilteredProperties) { p ->
                        MapPropertyCardItem(p = p, onClick = { onPropertyClick(p) })
                    }
                }
            }
        }
    }
}

@Composable
fun AreaMarker(
    name: String,
    count: Int,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val size = if (isSelected) 74.dp else 64.dp
    val color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
    val textColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSecondary

    Card(
        modifier = modifier
            .size(size)
            .clickable { onClick() },
        shape = CircleShape,
        colors = CardDefaults.cardColors(containerColor = color),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 6.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = name,
                fontSize = 9.sp,
                fontWeight = FontWeight.ExtraBold,
                color = textColor,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (isSelected) MaterialTheme.colorScheme.secondary else Color.White)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "$count pin",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
fun MapPropertyCardItem(
    p: Property,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(260.dp)
            .fillMaxHeight()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Stylized Icon representation
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (p.propertyType == "Office") Icons.Filled.Business else Icons.Filled.Apartment,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = p.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${p.neighborhood} · ${p.propertyType}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "৳${p.price.toInt()} / m",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 12.sp
                    )

                    if (p.verified) {
                        Icon(
                            imageVector = Icons.Filled.Verified,
                            contentDescription = "Verified Owner",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
