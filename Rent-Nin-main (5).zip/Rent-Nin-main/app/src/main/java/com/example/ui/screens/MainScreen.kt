package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.mutableStateListOf
import com.example.model.Property
import com.example.ui.RentViewModel

@Composable
fun MainScreen(
    viewModel: RentViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    val propertyHistory = remember { mutableStateListOf<Property>() }
    val currentProperty = propertyHistory.lastOrNull()
    var showCompareScreen by remember { mutableStateOf(false) }
    val compareIds by viewModel.selectedCompareIds.collectAsState()
    
    val cookieConsentAccepted by viewModel.cookieConsentAccepted.collectAsState()
    val context = LocalContext.current
    var showPrivacyPolicyDialog by remember { mutableStateOf(false) }

    if (currentProperty != null) {
        BackHandler {
            propertyHistory.removeAt(propertyHistory.lastIndex)
        }
        PropertyDetailScreen(
            p = currentProperty,
            viewModel = viewModel,
            onBackClick = { propertyHistory.removeAt(propertyHistory.lastIndex) },
            onPropertyClick = { propertyHistory.add(it) }
        )
    } else if (showCompareScreen) {
        BackHandler {
            showCompareScreen = false
        }
        CompareScreen(
            viewModel = viewModel,
            onBackClick = { showCompareScreen = false },
            onPropertyClick = { propertyHistory.add(it) }
        )
    } else {
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(imageVector = Icons.Filled.Home, contentDescription = "Explore") },
                        label = { Text("Explore", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(imageVector = Icons.Filled.Search, contentDescription = "Browse") },
                        label = { Text("Browse", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(imageVector = Icons.Filled.Favorite, contentDescription = "Favorites") },
                        label = { Text("Favorites", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(imageVector = Icons.Filled.Email, contentDescription = "Inquiries") },
                        label = { Text("Inquiries", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 4,
                        onClick = { selectedTab = 4 },
                        icon = { Icon(imageVector = Icons.Filled.Call, contentDescription = "Portal & Support") },
                        label = { Text("Portal", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Primary Tab Contents
                when (selectedTab) {
                    0 -> ExploreScreen(
                        viewModel = viewModel,
                        onPropertyClick = { propertyHistory.add(it) },
                        onNavigateToBrowse = { selectedTab = 1 }
                    )
                    1 -> BrowseScreen(
                        viewModel = viewModel,
                        onPropertyClick = { propertyHistory.add(it) }
                    )
                    2 -> FavoritesScreen(
                        viewModel = viewModel,
                        onPropertyClick = { propertyHistory.add(it) }
                    )
                    3 -> InquiriesScreen(
                        viewModel = viewModel
                    )
                    4 -> InfoScreen(
                        viewModel = viewModel
                    )
                }

                // --- COMPARE LISTINGS FLOATING BAR ---
                if (compareIds.isNotEmpty() && !showCompareScreen) {
                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = if (!cookieConsentAccepted) 140.dp else 16.dp, start = 16.dp, end = 16.dp)
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFF00B050).copy(alpha = 0.3f), RoundedCornerShape(28.dp))
                            .testTag("compare_floating_bar"),
                        shape = RoundedCornerShape(28.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.9f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CompareArrows,
                                    contentDescription = "Compare List",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Compare List (${compareIds.size}/3)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { viewModel.clearCompare() },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color.LightGray)
                                ) {
                                    Text("Clear", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = { showCompareScreen = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B050)),
                                    shape = RoundedCornerShape(16.dp),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                                ) {
                                    Text("Compare", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            }
                        }
                    }
                }

                // --- DATA COMPLIANCE: COOKIE CONSENT & PRIVACY POLICY FLOATING BANNER ---
                if (!cookieConsentAccepted) {
                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                            .testTag("cookie_consent_banner"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Shield,
                                    contentDescription = "Privacy Shield",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Cookie Consent & Privacy Policy",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Text(
                                text = "Rentnin uses cookies, SQLite local caches, and secure identifiers to analyze property traffic, save favorite listings, and broadcast OTP verify SMS in compliance with WCAG 2.1 AA and GDPR privacy protection regulations.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                lineHeight = 14.sp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { showPrivacyPolicyDialog = true },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    Text("Policy Details", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = { 
                                        viewModel.cookieConsentAccepted.value = true
                                        Toast.makeText(context, "🍪 Thank you! Privacy settings saved.", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    Text("Accept All", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Interactive Privacy Policy and Data compliance Dialog
    if (showPrivacyPolicyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyPolicyDialog = false },
            confirmButton = {
                TextButton(onClick = { showPrivacyPolicyDialog = false }) {
                    Text("I Understand")
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Rentnin Privacy Policy", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "1. Data Collection:\nWe store listing information, contact metrics, and OTP timestamps locally within a secure Room SQLite container. No personal listing drafts are uploaded without verification.",
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                    Text(
                        text = "2. Security Standards:\nWe verify seller phone numbers via simulated cellular OTP handshake to curb fraud. Duplicate entries are blocked automatically.",
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                    Text(
                        text = "3. Accessibility Compliance:\nWe strictly follow WCAG 2.1 AA color contrast, touch target standards, and screen reader labels across our property search platform.",
                        fontSize = 11.sp,
                        lineHeight = 14.sp
                    )
                }
            }
        )
    }
}
