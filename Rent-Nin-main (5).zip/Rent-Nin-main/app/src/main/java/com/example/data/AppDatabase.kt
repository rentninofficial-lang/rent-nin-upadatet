package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import com.example.model.FavoriteProperty
import com.example.model.Inquiry
import com.example.model.Property
import com.example.model.SearchHistory
import com.example.model.SavedSearch
import com.example.model.ChatMessage
import kotlinx.coroutines.flow.Flow

@Dao
interface PropertyDao {
    @Query("SELECT * FROM properties")
    fun getAllProperties(): Flow<List<Property>>

    @Query("SELECT * FROM properties WHERE slug = :slug LIMIT 1")
    suspend fun getPropertyBySlug(slug: String): Property?

    @Query("SELECT * FROM properties WHERE id = :id LIMIT 1")
    suspend fun getPropertyById(id: String): Property?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProperties(properties: List<Property>)

    @Query("UPDATE properties SET isRented = :isRented WHERE id = :id")
    suspend fun updateRentedStatus(id: String, isRented: Boolean)

    @Query("UPDATE properties SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementViews(id: String)

    @Query("UPDATE properties SET callsCount = callsCount + 1 WHERE id = :id")
    suspend fun incrementCalls(id: String)

    @Query("UPDATE properties SET whatsappClicksCount = whatsappClicksCount + 1 WHERE id = :id")
    suspend fun incrementWhatsappClicks(id: String)

    @Query("UPDATE properties SET isApproved = :approved WHERE id = :id")
    suspend fun updateApprovalStatus(id: String, approved: Boolean)

    @Query("UPDATE properties SET timestamp = :timestamp WHERE id = :id")
    suspend fun updateTimestamp(id: String, timestamp: Long)

    @Query("DELETE FROM properties WHERE id = :id")
    suspend fun deleteProperty(id: String)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites")
    fun getAllFavorites(): Flow<List<FavoriteProperty>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE propertyId = :propertyId)")
    fun isFavoriteFlow(propertyId: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE propertyId = :propertyId)")
    suspend fun isFavorite(propertyId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: FavoriteProperty)

    @Query("DELETE FROM favorites WHERE propertyId = :propertyId")
    suspend fun removeFavorite(propertyId: String)
}

@Dao
interface InquiryDao {
    @Query("SELECT * FROM inquiries ORDER BY timestamp DESC")
    fun getAllInquiries(): Flow<List<Inquiry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInquiry(inquiry: Inquiry)
}

@Dao
interface SearchHistoryDao {
    @Query("SELECT * FROM search_history ORDER BY timestamp DESC LIMIT 10")
    fun getRecentSearches(): Flow<List<SearchHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSearch(search: SearchHistory)

    @Query("DELETE FROM search_history WHERE `query` = :query")
    suspend fun deleteSearch(query: String)

    @Query("DELETE FROM search_history")
    suspend fun clearAllSearchHistory()
}

@Dao
interface SavedSearchDao {
    @Query("SELECT * FROM saved_searches ORDER BY timestamp DESC")
    fun getAllSavedSearches(): Flow<List<SavedSearch>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedSearch(search: SavedSearch)

    @Query("DELETE FROM saved_searches WHERE id = :id")
    suspend fun deleteSavedSearch(id: Int)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE propertyId = :propertyId ORDER BY timestamp ASC")
    fun getChatMessages(propertyId: String): Flow<List<ChatMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChatMessage(message: ChatMessage)
}

@Database(
    entities = [
        Property::class,
        FavoriteProperty::class,
        Inquiry::class,
        SearchHistory::class,
        SavedSearch::class,
        ChatMessage::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun propertyDao(): PropertyDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun inquiryDao(): InquiryDao
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun savedSearchDao(): SavedSearchDao
    abstract fun chatMessageDao(): ChatMessageDao
}
