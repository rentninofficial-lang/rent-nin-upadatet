package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.model.Property
import com.example.model.ChatMessage
import com.example.ui.RentViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun PropertyDetailScreen(
    p: Property,
    viewModel: RentViewModel,
    onBackClick: () -> Unit,
    onPropertyClick: (Property) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val favorites by viewModel.favorites.collectAsState(initial = emptyList())
    val isFavorited = favorites.any { it.propertyId == p.id }

    val allProperties by viewModel.allProperties.collectAsState(initial = emptyList())
    // Get similar listings in same neighborhood
    val similarProperties = remember(allProperties, p) {
        allProperties.filter { it.neighborhood == p.neighborhood && it.id != p.id && !it.isRented }
    }

    // Carousel Image State
    val imageList = remember(p) {
        val list = mutableListOf(p.imageUrl)
        if (p.additionalImages.isNotBlank()) {
            val splits = p.additionalImages.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            list.addAll(splits)
        }
        list
    }
    var selectedCarouselIndex by remember { mutableStateOf(0) }
    var zoomedImageUrl by remember { mutableStateOf<String?>(null) }

    // Dialog & UI states
    var showInquiryDialog by remember { mutableStateOf(false) }
    var showVerificationDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }
    var showChatDialog by remember { mutableStateOf(false) }
    var showSellerProfile by remember { mutableStateOf(false) }

    // Inquiry Inputs
    var inquirerName by remember { mutableStateOf("") }
    var inquirerPhone by remember { mutableStateOf("") }
    var inquirerDetails by remember { mutableStateOf("Hi! I am interested in viewing this property.") }

    // Report Inputs
    var reportReason by remember { mutableStateOf("Incorrect Price") }
    val reportReasons = listOf("Incorrect Price", "Duplicate Listing", "Unavailable/Rented", "Suspicious/Fraudulent")
    var reportComment by remember { mutableStateOf("") }

    // Chat Inputs
    var chatMessageText by remember { mutableStateOf("") }
    var inlineChatMessageText by remember { mutableStateOf("") }
    val chatMessages by viewModel.getChatMessages(p.id).collectAsState(initial = emptyList())

    // Track views
    LaunchedEffect(p.id) {
        viewModel.incrementPropertyViews(p.id)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (p.ownerName.contains("Premium") || p.ownerName.contains("Owner")) "Asset Care Services Real Estate Agent" else "${p.ownerName} Real Estate Agent",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.Black
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleFavorite(p.id) }) {
                        val isFavoritedLocal = favorites.any { it.propertyId == p.id }
                        Icon(
                            imageVector = if (isFavoritedLocal) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                            contentDescription = "Save",
                            tint = if (isFavoritedLocal) Color(0xFF00B050) else Color.Black
                        )
                    }
                    IconButton(onClick = { showReportDialog = true }) {
                        Icon(
                            imageVector = Icons.Filled.MoreVert,
                            contentDescription = "More",
                            tint = Color.Black
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding(), bottom = innerPadding.calculateBottomPadding())
                .verticalScroll(scrollState)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Photo Gallery / Carousel per listing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                AsyncImage(
                    model = imageList[selectedCarouselIndex],
                    contentDescription = p.title,
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { zoomedImageUrl = imageList[selectedCarouselIndex] },
                    contentScale = ContentScale.Crop
                )

                // Carousel Left/Right arrows overlay if multiple images exist
                if (imageList.size > 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.Center)
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = {
                                selectedCarouselIndex = if (selectedCarouselIndex == 0) imageList.lastIndex else selectedCarouselIndex - 1
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Previous Photo", tint = Color.White, modifier = Modifier.size(18.dp))
                        }

                        IconButton(
                            onClick = {
                                selectedCarouselIndex = if (selectedCarouselIndex == imageList.lastIndex) 0 else selectedCarouselIndex + 1
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Photo", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }

                    // Indicator Dots
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 12.dp)
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        imageList.forEachIndexed { index, _ ->
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(if (index == selectedCarouselIndex) MaterialTheme.colorScheme.secondary else Color.White.copy(alpha = 0.6f))
                            )
                        }
                    }
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                // Location, post time and premium star badge
                val hoursAgo = remember(p) { ((System.currentTimeMillis() - p.timestamp) / (1000 * 60 * 60)).coerceIn(1, 23) }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = "Location",
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${p.city}, ${p.neighborhood}, $hoursAgo hours ago",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                    
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = "Verified Premium",
                        tint = Color(0xFFFFB300),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Title
                Text(
                    text = p.title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.Black,
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Price with BDT green bold formatting
                Text(
                    text = "BDT ${p.price.toInt().toString().reversed().chunked(3).joinToString(",").reversed().replace("^,|-,", "")}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF00B050)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Call and Request call back side-by-side buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Request Call Back
                    OutlinedButton(
                        onClick = {
                            viewModel.submitInquiry(
                                name = "Visitor Request",
                                phone = "+8801700000000",
                                details = "Call back requested for verified property: ${p.title}",
                                propertyTitle = p.title,
                                type = "Call Back"
                            )
                            Toast.makeText(context, "Call back requested! Our agent will contact you shortly.", Toast.LENGTH_LONG).show()
                        },
                        border = BorderStroke(1.dp, Color(0xFF00B050)),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF00B050)),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("Request call back", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    // Call
                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.ownerPhone}"))
                            context.startActivity(intent)
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B050)),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Call", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Chat with the seller section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Chat with the seller",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.Black
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick suggestion pills
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val chips = listOf("Make an offer", "Is this available", "Last price")
                            chips.forEach { chipText ->
                                Box(
                                    modifier = Modifier
                                        .border(1.dp, Color(0xFF00B050), RoundedCornerShape(16.dp))
                                        .clickable {
                                            inlineChatMessageText = when (chipText) {
                                                "Make an offer" -> "I would like to make an offer of BDT ${p.price.toInt()} for this property."
                                                "Is this available" -> "Hi, is this property available?"
                                                "Last price" -> "Hi, what is the last price for this property?"
                                                else -> chipText
                                            }
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = chipText,
                                        color = Color(0xFF00B050),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Text input box
                        OutlinedTextField(
                            value = inlineChatMessageText,
                            onValueChange = { inlineChatMessageText = it },
                            placeholder = { Text("Write your message here", color = Color.Gray, fontSize = 13.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF00B050),
                                unfocusedBorderColor = Color.LightGray
                            )
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Start chat orange button
                        Button(
                            onClick = {
                                val msgText = inlineChatMessageText.ifBlank { "Hi, is this property available?" }
                                viewModel.sendChatMessage(
                                    propertyId = p.id,
                                    propertyTitle = p.title,
                                    senderName = "You",
                                    text = msgText,
                                    isFromUser = true
                                )
                                inlineChatMessageText = ""
                                
                                // Simulate response
                                scope.launch {
                                    delay(1500)
                                    viewModel.sendChatMessage(
                                        propertyId = p.id,
                                        propertyTitle = p.title,
                                        senderName = p.ownerName,
                                        text = "Thanks for reaching out! Yes, this property at ${p.address} is available. When would you like to inspect it?",
                                        isFromUser = false
                                    )
                                }
                                Toast.makeText(context, "Secure chat started!", Toast.LENGTH_SHORT).show()
                                showChatDialog = true
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFE9A3A)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                        ) {
                            Text("Start chat", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Property Specifications Grid (2-column key-value list card)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Row 1
                        Row(modifier = Modifier.fillMaxWidth()) {
                            SpecGridItem(value = p.propertyType, label = "Property Type", modifier = Modifier.weight(1f))
                            SpecGridItem(value = p.address, label = "Address", modifier = Modifier.weight(1f))
                        }
                        
                        Divider(color = Color.LightGray.copy(alpha = 0.3f))

                        // Row 2
                        Row(modifier = Modifier.fillMaxWidth()) {
                            val furText = if (p.furnished) "Furnished" else "Unfurnished"
                            val condText = if (p.featured) "Brand New" else "Fairly Used"
                            SpecGridItem(value = furText, label = "Furnishing", modifier = Modifier.weight(1f))
                            SpecGridItem(value = condText, label = "Condition", modifier = Modifier.weight(1f))
                        }

                        Divider(color = Color.LightGray.copy(alpha = 0.3f))

                        // Row 3
                        Row(modifier = Modifier.fillMaxWidth()) {
                            val pkText = if (p.bedrooms > 2) "2" else "1"
                            SpecGridItem(value = pkText, label = "Parking Spaces", modifier = Modifier.weight(1f))
                            SpecGridItem(value = p.areaSqft.toString(), label = "Property Size", modifier = Modifier.weight(1f))
                        }

                        Divider(color = Color.LightGray.copy(alpha = 0.3f))

                        // Row 4
                        Row(modifier = Modifier.fillMaxWidth()) {
                            val minPeriod = if (p.propertyType == "Office" || p.propertyType == "Commercial") "730 Days" else "360 Days"
                            SpecGridItem(value = minPeriod, label = "Minimum Rental Period", modifier = Modifier.weight(1f))
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Info Message Banner: "Please Call For More Information. Call"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.LightGray.copy(alpha = 0.15f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.ownerPhone}"))
                                context.startActivity(intent)
                            }
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Please Call For More Information. Call",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // About this space (Description)
                Text(
                    text = "About this space",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = p.description,
                    fontSize = 13.sp,
                    color = Color.DarkGray,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Listed by Seller Profile section
                Text(
                    text = "Listed by Seller",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showSellerProfile = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Avatar
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = p.ownerName.first().toString(),
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.secondary,
                                fontSize = 18.sp
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(p.ownerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                if (p.verified) {
                                    Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                                }
                            }

                            // Account Type Badge
                            val isAgent = p.sellerType.equals("agent", ignoreCase = true) || p.sellerType.equals("agency", ignoreCase = true)
                            val badgeColor = if (isAgent) Color(0xFFF57C00) else Color(0xFF00796B)
                            val badgeText = if (isAgent) "Agency Agent" else "Individual Owner"
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .padding(vertical = 2.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(badgeColor.copy(alpha = 0.12f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = if (isAgent) Icons.Filled.SupportAgent else Icons.Filled.Person,
                                    contentDescription = null,
                                    tint = badgeColor,
                                    modifier = Modifier.size(10.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = badgeText,
                                    color = badgeColor,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(12.dp))
                                    Text(p.ownerRating.toString(), fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                }
                                Text("·", fontSize = 11.sp, color = Color.Gray)
                                Text("Response: ${p.ownerResponseTime}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        // Arrow indicator
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Profile", color = MaterialTheme.colorScheme.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Similar / Nearby listings recommendations
                if (similarProperties.isNotEmpty()) {
                    Text(
                        text = "Similar properties in ${p.neighborhood}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(similarProperties) { item ->
                            SimilarPropertyCardItem(p = item, onClick = { onPropertyClick(item) })
                        }
                    }
                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }

    // Photo Fullscreen Zoom Support Dialog
    if (zoomedImageUrl != null) {
        Dialog(
            onDismissRequest = { zoomedImageUrl = null }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .clickable { zoomedImageUrl = null }
            ) {
                AsyncImage(
                    model = zoomedImageUrl,
                    contentDescription = "Zoomed Image View",
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Fit
                )

                // Top instructions
                Text(
                    text = "Double Tap / Click anywhere to close",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(24.dp)
                )
            }
        }
    }

    // "Verified Owner" Trust Portal Educational Dialog
    if (showVerificationDialog) {
        AlertDialog(
            onDismissRequest = { showVerificationDialog = false },
            title = { Text("Rentnin 4-Step Trust Verification Protocol", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("This property owner has completed our rigorous multi-point screening criteria:", fontSize = 12.sp, color = Color.Gray)
                    VerificationBullet(step = "1", title = "National ID Registry Link", desc = "Corroborated owner's verified NID document in the local system.")
                    VerificationBullet(step = "2", title = "Land Deed Review", desc = "Valid ownership title checks to ensure authority to list.")
                    VerificationBullet(step = "3", title = "Physical Site Vetting", desc = "On-site photos and physical address auditing by our agents.")
                    VerificationBullet(step = "4", title = "Safe Contact Check", desc = "Active landlord phone confirmation to verify zero broker middlemen.")
                }
            },
            confirmButton = {
                Button(onClick = { showVerificationDialog = false }) {
                    Text("Got It")
                }
            }
        )
    }

    // Report Suspicion Dialog
    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Report Listing", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Help keep Rentnin safe. Let us know what is incorrect about this listing:", fontSize = 12.sp, color = Color.Gray)

                    // Dropdown simulation via buttons
                    reportReasons.forEach { reason ->
                        val isSel = reportReason == reason
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .clickable { reportReason = reason }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = isSel, onClick = { reportReason = reason })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(reason, fontSize = 13.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                        }
                    }

                    OutlinedTextField(
                        value = reportComment,
                        onValueChange = { reportComment = it },
                        label = { Text("Additional information / comments") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reportDetails = "Reported Property ID: ${p.id}\nReason: $reportReason\nComment: $reportComment"
                        viewModel.submitInquiry(
                            name = "User Report System",
                            phone = "+8801700000000",
                            details = reportDetails,
                            propertyTitle = "Listing Report: ${p.title}",
                            type = "Report/Flag"
                        )
                        Toast.makeText(context, "Listing reported successfully! Our team will audit this immediately.", Toast.LENGTH_LONG).show()
                        showReportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) {
                    Text("Submit Report", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    // In-App Chat Dialog UI Drawer
    if (showChatDialog) {
        AlertDialog(
            onDismissRequest = { showChatDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(p.ownerName.first().toString(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                    }
                    Column {
                        Text(p.ownerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Active · Replies ${p.ownerResponseTime}", fontSize = 10.sp, color = Color.Gray)
                    }
                }
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Messages List
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            if (chatMessages.isEmpty()) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.Center,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Filled.Email, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Start a secure conversation directly.", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
                                    Text("Zero agency commission guaranteed.", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    val chatScroll = rememberScrollState()
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(chatScroll)
                                            .padding(bottom = 8.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        for (msg in chatMessages) {
                                            val bubbleAlign = if (msg.isFromUser) Alignment.End else Alignment.Start
                                            val bubbleBg = if (msg.isFromUser) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.35f)
                                            val bubbleTextCol = if (msg.isFromUser) Color.White else Color.Black

                                            Column(modifier = Modifier.align(bubbleAlign)) {
                                                Box(
                                                    modifier = Modifier
                                                        .clip(RoundedCornerShape(12.dp))
                                                        .background(bubbleBg)
                                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                                ) {
                                                    Text(msg.messageText, color = bubbleTextCol, fontSize = 12.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color.LightGray.copy(alpha = 0.5f))

                        // Message Sender Input Bar
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            OutlinedTextField(
                                value = chatMessageText,
                                onValueChange = { chatMessageText = it },
                                placeholder = { Text("Write securely...", fontSize = 12.sp) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp),
                                singleLine = true,
                                shape = RoundedCornerShape(24.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = Color.LightGray
                                )
                            )

                            IconButton(
                                onClick = {
                                    if (chatMessageText.isNotBlank()) {
                                        val sent = chatMessageText
                                        viewModel.sendChatMessage(
                                            propertyId = p.id,
                                            propertyTitle = p.title,
                                            senderName = "You",
                                            text = sent,
                                            isFromUser = true
                                        )
                                        chatMessageText = ""

                                        // Simulate realistic automated response after 1.5 seconds!
                                        scope.launch {
                                            delay(1500)
                                            val reply = when {
                                                sent.contains("rent", ignoreCase = true) || sent.contains("price", ignoreCase = true) -> {
                                                    "The monthly rent is ৳${p.price.toInt()} with no security deposit brokers. When would you like to visit?"
                                                }
                                                sent.contains("visit", ignoreCase = true) || sent.contains("view", ignoreCase = true) || sent.contains("visit", ignoreCase = true) -> {
                                                    "Sure, I can show you around tomorrow. Does 4:00 PM BST work for you?"
                                                }
                                                else -> "Thanks for reaching out! Yes, this property at ${p.address} is available. Let me know if you want to inspect it."
                                            }
                                            viewModel.sendChatMessage(
                                                propertyId = p.id,
                                                propertyTitle = p.title,
                                                senderName = p.ownerName,
                                                text = reply,
                                                isFromUser = false
                                            )
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                            ) {
                                Icon(Icons.Filled.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChatDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // In-App Inquiry Dialog Form
    if (showInquiryDialog) {
        AlertDialog(
            onDismissRequest = { showInquiryDialog = false },
            title = { Text("Send Direct Inquiry", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = inquirerName,
                        onValueChange = { inquirerName = it },
                        label = { Text("Your Full Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = inquirerPhone,
                        onValueChange = { inquirerPhone = it },
                        label = { Text("Your Contact Phone") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                    OutlinedTextField(
                        value = inquirerDetails,
                        onValueChange = { inquirerDetails = it },
                        label = { Text("Message / Enquiry Specifications") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (inquirerName.isEmpty() || inquirerPhone.isEmpty()) {
                            Toast.makeText(context, "Full Name and Contact Phone are required.", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.submitInquiry(
                                name = inquirerName,
                                phone = inquirerPhone,
                                details = inquirerDetails,
                                propertyTitle = p.title,
                                type = "Property Inquiry"
                            )
                            Toast.makeText(context, "Inquiry registered! The landlord will call you shortly.", Toast.LENGTH_LONG).show()
                            showInquiryDialog = false
                        }
                    }
                ) {
                    Text("Submit Inquiry")
                }
            },
            dismissButton = {
                TextButton(onClick = { showInquiryDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    if (showSellerProfile) {
        val sellerListings = allProperties.filter { 
            (it.ownerPhone == p.ownerPhone || it.ownerName == p.ownerName) && !it.isDraft && !it.isRented
        }
        AlertDialog(
            onDismissRequest = { showSellerProfile = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = p.ownerName.first().toString(),
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 22.sp
                        )
                    }
                    Column {
                        Text(p.ownerName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        val isAgent = p.sellerType.equals("agent", ignoreCase = true) || p.sellerType.equals("agency", ignoreCase = true)
                        val badgeColor = if (isAgent) Color(0xFFF57C00) else Color(0xFF00796B)
                        val badgeText = if (isAgent) "Verified Agency Agent" else "Verified Private Owner"
                        Text(
                            text = badgeText,
                            color = badgeColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Stats Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Rating", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(12.dp))
                                Text(p.ownerRating.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Active Ads", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(sellerListings.size.toString(), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Member Since", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text("Oct 2024", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Response", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text("98%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF388E3C))
                        }
                    }

                    Text("Active Listings (${sellerListings.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)

                    if (sellerListings.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            Text("No other active listings from this seller.", color = Color.Gray, fontSize = 11.sp)
                        }
                    } else {
                        val listState = rememberScrollState()
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false)
                                .verticalScroll(listState),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            sellerListings.forEach { item ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                        .border(1.dp, Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                        .clickable {
                                            showSellerProfile = false
                                            onPropertyClick(item)
                                        }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    AsyncImage(
                                        model = item.imageUrl,
                                        contentDescription = item.title,
                                        modifier = Modifier
                                            .size(50.dp)
                                            .clip(RoundedCornerShape(6.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(item.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text("${item.neighborhood} · ৳${item.price.toInt()}/mo", fontSize = 10.sp, color = Color.Gray)
                                    }
                                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSellerProfile = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
fun VerificationBullet(step: String, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
        ) {
            Text(step, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Text(desc, fontSize = 10.sp, color = Color.Gray, lineHeight = 13.sp)
        }
    }
}

@Composable
fun SimilarPropertyCardItem(
    p: Property,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(200.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                AsyncImage(
                    model = p.imageUrl,
                    contentDescription = p.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                if (p.verified) {
                    Icon(
                        imageVector = Icons.Filled.Verified,
                        contentDescription = "Verified",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                            .background(Color.White, CircleShape)
                            .padding(2.dp)
                            .size(16.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = p.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "৳${p.price.toInt()} /mo",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = "${p.bedrooms} Beds · ${p.areaSqft} sqft",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun SpecsColumn(label: String, value: String) {
    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun SpecGridItem(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(vertical = 8.dp, horizontal = 4.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color.Black
        )
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color.Gray
        )
    }
}
