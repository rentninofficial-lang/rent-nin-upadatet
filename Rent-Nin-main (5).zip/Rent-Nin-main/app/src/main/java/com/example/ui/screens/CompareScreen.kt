package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Property
import com.example.ui.RentViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompareScreen(
    viewModel: RentViewModel,
    onBackClick: () -> Unit,
    onPropertyClick: (Property) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val allProperties by viewModel.allProperties.collectAsState(initial = emptyList())
    val compareIds by viewModel.selectedCompareIds.collectAsState()
    
    val compareProperties = remember(compareIds, allProperties) {
        allProperties.filter { compareIds.contains(it.id) }.take(3)
    }

    var highlightDifferences by remember { mutableStateOf(false) }

    // Smart recommendations: find lowest rent and largest area
    val minPricePropertyId = remember(compareProperties) {
        if (compareProperties.size >= 2) {
            compareProperties.minByOrNull { it.price }?.id
        } else null
    }
    val maxSizePropertyId = remember(compareProperties) {
        if (compareProperties.size >= 2) {
            compareProperties.maxByOrNull { it.areaSqft }?.id
        } else null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Compare Listings (${compareProperties.size}/3)",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.Black
                        )
                    }
                },
                actions = {
                    if (compareProperties.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                val shareText = buildString {
                                    appendLine("🏢 RentNin Property Comparison Report 🏢")
                                    appendLine("Compare these listings side-by-side:")
                                    appendLine("--------------------------------------")
                                    compareProperties.forEachIndexed { index, p ->
                                        appendLine("${index + 1}. ${p.title}")
                                        appendLine("   • Rent: ৳${p.price.toInt()}/month")
                                        appendLine("   • Location: ${p.neighborhood}")
                                        appendLine("   • Specs: ${p.bedrooms} Beds, ${p.bathrooms} Baths, ${p.areaSqft} sqft (${if (p.furnished) "Furnished" else "Unfurnished"})")
                                        appendLine("   • Owner: ${p.ownerName} (${p.ownerPhone})")
                                        appendLine()
                                    }
                                    append("Shared via RentNin App ⚡")
                                }
                                clipboardManager.setText(AnnotatedString(shareText))
                                Toast.makeText(context, "Comparison report copied to clipboard!", Toast.LENGTH_LONG).show()
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = "Share Comparison",
                                tint = Color(0xFF00B050)
                            )
                        }

                        TextButton(
                            onClick = { viewModel.clearCompare() },
                            colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF00B050))
                        ) {
                            Text("Clear All", fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF9F9F9))
        ) {
            if (compareProperties.size < 2) {
                // Empty state or less than 2 properties selected
                EmptyCompareState(
                    selectedCount = compareProperties.size,
                    allProperties = allProperties.filter { !it.isDraft && it.isApproved && !it.isExpired },
                    compareIds = compareIds,
                    onToggleCompare = { viewModel.toggleCompare(it) }
                )
            } else {
                // Table Comparison View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Side-by-side Properties Headers
                    Surface(
                        tonalElevation = 2.dp,
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Column 1: Labels offset space
                            Spacer(modifier = Modifier.weight(0.8f))

                            // Properties Cards
                            compareProperties.forEach { p ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                        .clickable { onPropertyClick(p) }
                                ) {
                                    Column {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(90.dp)
                                        ) {
                                            AsyncImage(
                                                model = p.imageUrl,
                                                contentDescription = p.title,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                            
                                            // Close / Remove button
                                            IconButton(
                                                onClick = { viewModel.toggleCompare(p.id) },
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .padding(4.dp)
                                                    .size(24.dp)
                                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.Close,
                                                    contentDescription = "Remove",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            // Smart Badges
                                            Row(
                                                modifier = Modifier
                                                    .align(Alignment.BottomStart)
                                                    .padding(4.dp),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                if (p.id == minPricePropertyId) {
                                                    Surface(
                                                        color = Color(0xFF00B050),
                                                        shape = RoundedCornerShape(4.dp),
                                                        shadowElevation = 2.dp
                                                    ) {
                                                        Text(
                                                            text = "Best Rent",
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.White,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                if (p.id == maxSizePropertyId) {
                                                    Surface(
                                                        color = Color(0xFFFE9A3A),
                                                        shape = RoundedCornerShape(4.dp),
                                                        shadowElevation = 2.dp
                                                    ) {
                                                        Text(
                                                            text = "Largest",
                                                            fontSize = 8.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = Color.White,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Text(
                                                text = p.title,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.Black,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis,
                                                lineHeight = 14.sp
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "৳${p.price.toInt()}/mo",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF00B050)
                                            )
                                        }
                                    }
                                }
                            }
                            
                            // Fill remaining space if comparing only 2
                            if (compareProperties.size < 3) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(150.dp)
                                        .background(Color(0xFFF2F2F2), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "+ Add listing",
                                        fontSize = 12.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Attribute Comparison Options Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .border(1.dp, Color.LightGray.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .clickable { highlightDifferences = !highlightDifferences }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = null,
                                tint = Color(0xFF00B050),
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Highlight Differences",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.DarkGray
                            )
                        }
                        Switch(
                            checked = highlightDifferences,
                            onCheckedChange = { highlightDifferences = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF00B050),
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color(0xFFEEEEEE)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Compute dynamic row differences
                    val pricesDiff = remember(compareProperties) { compareProperties.map { it.price.toInt() }.distinct().size > 1 }
                    val typesDiff = remember(compareProperties) { compareProperties.map { it.propertyType }.distinct().size > 1 }
                    val neighborhoodsDiff = remember(compareProperties) { compareProperties.map { it.neighborhood }.distinct().size > 1 }
                    val sizesDiff = remember(compareProperties) { compareProperties.map { it.areaSqft }.distinct().size > 1 }
                    val bedsDiff = remember(compareProperties) { compareProperties.map { it.bedrooms }.distinct().size > 1 }
                    val bathsDiff = remember(compareProperties) { compareProperties.map { it.bathrooms }.distinct().size > 1 }
                    val furnishedDiff = remember(compareProperties) { compareProperties.map { if (it.furnished) 1 else 0 }.distinct().size > 1 }
                    val ratingsDiff = remember(compareProperties) { compareProperties.map { it.ownerRating }.distinct().size > 1 }
                    val sellersDiff = remember(compareProperties) { compareProperties.map { it.ownerName }.distinct().size > 1 }
                    val sellerTypesDiff = remember(compareProperties) { compareProperties.map { it.sellerType }.distinct().size > 1 }

                    // Attribute Comparison Rows
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                    ) {
                        Column {
                            CompareRow(label = "Price", values = compareProperties.map { "BDT ${it.price.toInt()}/mo" }, isHighlighted = highlightDifferences && pricesDiff)
                            CompareRow(label = "Type", values = compareProperties.map { it.propertyType }, isHighlighted = highlightDifferences && typesDiff)
                            CompareRow(label = "Neighborhood", values = compareProperties.map { it.neighborhood }, isHighlighted = highlightDifferences && neighborhoodsDiff)
                            CompareRow(label = "Size", values = compareProperties.map { "${it.areaSqft} sqft" }, isHighlighted = highlightDifferences && sizesDiff)
                            CompareRow(label = "Bedrooms", values = compareProperties.map { "${it.bedrooms} Beds" }, isHighlighted = highlightDifferences && bedsDiff)
                            CompareRow(label = "Bathrooms", values = compareProperties.map { "${it.bathrooms} Baths" }, isHighlighted = highlightDifferences && bathsDiff)
                            CompareRow(label = "Furnishing", values = compareProperties.map { if (it.furnished) "Furnished" else "Unfurnished" }, isHighlighted = highlightDifferences && furnishedDiff)
                            CompareRow(label = "Rating", values = compareProperties.map { "${it.ownerRating} ★" }, isHighlighted = highlightDifferences && ratingsDiff)
                            CompareRow(label = "Seller", values = compareProperties.map { it.ownerName }, isHighlighted = highlightDifferences && sellersDiff)
                            CompareRow(label = "Listed By", values = compareProperties.map { it.sellerType }, isHighlighted = highlightDifferences && sellerTypesDiff)
                            
                            // Actions Row
                            Divider(color = Color.LightGray.copy(alpha = 0.4f))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Empty label cell
                                Text(
                                    text = "Inquire",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black,
                                    modifier = Modifier.weight(0.8f)
                                )

                                compareProperties.forEach { p ->
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        // Quick Call Button
                                        IconButton(
                                            onClick = {
                                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.ownerPhone}"))
                                                context.startActivity(intent)
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(36.dp)
                                                .background(Color(0xFF00B050), RoundedCornerShape(6.dp))
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Call,
                                                contentDescription = "Call",
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }

                                        // Quick Chat Button
                                        IconButton(
                                            onClick = {
                                                viewModel.sendChatMessage(
                                                    propertyId = p.id,
                                                    propertyTitle = p.title,
                                                    senderName = "You",
                                                    text = "Hi, I am interested in comparing this property. Is it available?",
                                                    isFromUser = true
                                                )
                                                Toast.makeText(context, "Chat inquiry sent!", Toast.LENGTH_SHORT).show()
                                                onPropertyClick(p)
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(36.dp)
                                                .background(Color(0xFFFE9A3A), RoundedCornerShape(6.dp))
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Email,
                                                contentDescription = "Chat",
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }

                                if (compareProperties.size < 3) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompareRow(
    label: String,
    values: List<String>,
    isHighlighted: Boolean = false
) {
    Column(
        modifier = Modifier.background(if (isHighlighted) Color(0xFFFFF9E6) else Color.Transparent)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Label column
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isHighlighted) Color(0xFFD47A1B) else Color.Gray,
                modifier = Modifier.weight(0.8f)
            )

            // Value columns
            values.forEach { value ->
                Text(
                    text = value,
                    fontSize = 12.sp,
                    fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Medium,
                    color = Color.Black,
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Start,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Empty space filler if less than 3 columns
            if (values.size < 3) {
                Spacer(modifier = Modifier.weight(1f))
            }
        }
        Divider(color = if (isHighlighted) Color(0xFFFBE6B5) else Color.LightGray.copy(alpha = 0.3f))
    }
}

@Composable
fun EmptyCompareState(
    selectedCount: Int,
    allProperties: List<Property>,
    compareIds: Set<String>,
    onToggleCompare: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Filled.CompareArrows,
            contentDescription = null,
            tint = Color(0xFF00B050),
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Select Properties to Compare",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = if (selectedCount == 0) {
                "Select 2 or 3 listings to view their key attributes side-by-side. Tap the compare icon ( ⇄ ) on any property card."
            } else {
                "You have selected 1 property. Select at least 1 more property to compare side-by-side."
            },
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )
        
        Spacer(modifier = Modifier.height(32.dp))

        // Fast Selection helper list
        Text(
            text = "Quick add listings to compare:",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Start
        )
        Spacer(modifier = Modifier.height(12.dp))

        allProperties.take(6).forEach { p ->
            val isSelected = compareIds.contains(p.id)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .background(Color.White, RoundedCornerShape(8.dp))
                    .border(
                        1.dp,
                        if (isSelected) Color(0xFF00B050) else Color.LightGray.copy(alpha = 0.5f),
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onToggleCompare(p.id) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = p.imageUrl,
                    contentDescription = p.title,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = p.title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = Color.Black
                    )
                    Text(
                        text = "${p.neighborhood} • ৳${p.price.toInt()}/mo",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckCircle else Icons.Filled.Add,
                    contentDescription = if (isSelected) "Selected" else "Add",
                    tint = if (isSelected) Color(0xFF00B050) else Color.Gray,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
